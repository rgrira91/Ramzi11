package com.example;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import androidx.test.core.app.ApplicationProvider;
import com.example.audio.AudioFxEngine;
import com.example.ui.theme.AlbumColorExtractor;
import com.example.ui.theme.NeonPalette;
import com.example.widget.NeonWaveWidgetProvider;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.annotation.Config;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

@RunWith(RobolectricTestRunner.class)
@Config(sdk = 36)
public class ExampleRobolectricTest {
    @Test
    public void readAppNameFromContext() {
        Context context = ApplicationProvider.getApplicationContext();
        String appName = context.getString(R.string.app_name);
        assertEquals("NeonWave", appName);
    }

    @Test
    public void audioFxEngine_togglesPersistAndWidgetUpdatesSafely() {
        Context context = ApplicationProvider.getApplicationContext();
        AudioFxEngine fx = AudioFxEngine.getInstance();
        fx.init(context);

        fx.setSkipSilenceEnabled(true);
        assertTrue(fx.isSkipSilenceEnabled());
        fx.setSkipSilenceEnabled(false);
        assertFalse(fx.isSkipSilenceEnabled());

        fx.setSmoothFadeEnabled(false);
        assertFalse(fx.isSmoothFadeEnabled());
        fx.setSmoothFadeEnabled(true);
        assertTrue(fx.isSmoothFadeEnabled());

        assertTrue(fx.isDynamicThemeEnabled());
        fx.setDynamicThemeEnabled(false);
        assertFalse(fx.isDynamicThemeEnabled());
        fx.setDynamicThemeEnabled(true);
        assertTrue(fx.isDynamicThemeEnabled());

        NeonWaveWidgetProvider.updateAllWidgets(context, "Electric Dreams", "Nova Pulse", true);
    }

    @Test
    public void albumColorExtractor_extractsDistinctVibrantNeonPalette() {
        assertEquals(NeonPalette.DEFAULT, AlbumColorExtractor.extract(null));

        // Grayscale bitmap should cleanly fall back to NeonPalette.DEFAULT
        Bitmap gray = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888);
        gray.eraseColor(Color.rgb(80, 80, 80));
        assertEquals(NeonPalette.DEFAULT.primaryNeon, AlbumColorExtractor.extract(gray).primaryNeon);
        gray.recycle();

        // Rich emerald + amber cover art should produce distinct high-vibrancy neon accents and dark canvas
        Bitmap art = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(art);
        Paint p = new Paint();
        p.setColor(Color.rgb(16, 185, 129)); // Emerald green dominant
        c.drawRect(0, 0, 32, 48, p);
        p.setColor(Color.rgb(245, 158, 11)); // Warm amber accent
        c.drawRect(32, 0, 48, 48, p);

        NeonPalette extracted = AlbumColorExtractor.extract(art);
        art.recycle();

        assertNotEquals(NeonPalette.DEFAULT.primaryNeon, extracted.primaryNeon);
        float[] primaryHsv = new float[3];
        float[] secondaryHsv = new float[3];
        float[] canvasHsv = new float[3];
        Color.colorToHSV(extracted.primaryNeon, primaryHsv);
        Color.colorToHSV(extracted.secondaryNeon, secondaryHsv);
        Color.colorToHSV(extracted.canvasEnd, canvasHsv);

        assertTrue(primaryHsv[1] >= 0.70f);
        assertTrue(primaryHsv[2] >= 0.85f);
        assertTrue(AlbumColorExtractor.hueDistance(primaryHsv[0], secondaryHsv[0]) >= 35f);
        assertTrue(canvasHsv[2] <= 0.15f);

        NeonPalette mid = NeonPalette.lerp(NeonPalette.DEFAULT, extracted, 0.5f);
        assertNotEquals(NeonPalette.DEFAULT.primaryNeon, mid.primaryNeon);
        assertNotEquals(extracted.primaryNeon, mid.primaryNeon);
    }

    @Test
    public void uiStylePreferences_persistsSelectedInterfaceAndControls() {
        Context context = ApplicationProvider.getApplicationContext();
        com.example.ui.theme.UiStylePreferences prefs = new com.example.ui.theme.UiStylePreferences(context);

        assertEquals(com.example.ui.theme.UiStyleMode.NEON_COSMIC, prefs.getActiveStyle());
        prefs.setActiveStyle(com.example.ui.theme.UiStyleMode.RETRO_VINYL);
        assertEquals(com.example.ui.theme.UiStyleMode.RETRO_VINYL, prefs.getActiveStyle());

        prefs.setActiveStyle(com.example.ui.theme.UiStyleMode.LIQUID_GLASS);
        assertEquals(com.example.ui.theme.UiStyleMode.LIQUID_GLASS, prefs.getActiveStyle());

        prefs.setActiveStyle(com.example.ui.theme.UiStyleMode.FLOATING_MINI);
        assertEquals(com.example.ui.theme.UiStyleMode.FLOATING_MINI, prefs.getActiveStyle());

        prefs.setFloatingMiniCollapsed(true);
        assertTrue(prefs.isFloatingMiniCollapsed());

        prefs.setShowEqInCustomStyles(false);
        assertFalse(prefs.isShowEqInCustomStyles());
    }

    @Test
    public void deviceResourceOptimizer_adaptsFpsBuffersOffloadAndPersistsModes() {
        Context context = ApplicationProvider.getApplicationContext();
        com.example.util.DeviceResourceOptimizer opt = com.example.util.DeviceResourceOptimizer.getInstance(context);

        opt.setMode(com.example.util.DeviceResourceOptimizer.OptimizationMode.ECO_BATTERY);
        assertEquals(com.example.util.DeviceResourceOptimizer.OptimizationMode.ECO_BATTERY, opt.getMode());
        assertEquals(com.example.util.DeviceResourceOptimizer.EffectiveTier.POWER_SAVER, opt.getEffectiveTier());
        assertEquals(24, opt.getTargetVisualFps());
        assertFalse(opt.shouldAnimateThemeTransitions());
        assertTrue(opt.shouldUseAudioOffload(true));

        opt.setMode(com.example.util.DeviceResourceOptimizer.OptimizationMode.PERFORMANCE);
        assertEquals(com.example.util.DeviceResourceOptimizer.OptimizationMode.PERFORMANCE, opt.getMode());
        assertEquals(60, opt.getTargetVisualFps());
        assertTrue(opt.shouldAnimateThemeTransitions());

        opt.setAudioOffloadPreferred(false);
        assertFalse(opt.shouldUseAudioOffload(false));
        opt.setAudioOffloadPreferred(true);
        assertTrue(opt.shouldUseAudioOffload(false));

        opt.setMediaAntiStutterEnabled(true);
        int[] antiStutterBuf = opt.getExoBufferConfig();
        assertEquals(5, antiStutterBuf.length);
        assertTrue(antiStutterBuf[0] >= 20_000);

        opt.setMode(com.example.util.DeviceResourceOptimizer.OptimizationMode.AUTO);
        com.example.util.DeviceResourceOptimizer.DeviceTelemetry telemetry = opt.evaluateTelemetry();
        assertTrue(telemetry.cpuCores >= 1);
        assertTrue(telemetry.totalRamMb > 0);
    }

    @Test
    public void audioLibraryRepository_trimMemoryAndShutdownDoNotCrash() {
        Context context = ApplicationProvider.getApplicationContext();
        com.example.data.AudioLibraryRepository repo = new com.example.data.AudioLibraryRepository(context);
        repo.trimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW);
        repo.clearArtCache();
        assertEquals(0, repo.getArtCacheKb());
        repo.shutdown();
    }
}
