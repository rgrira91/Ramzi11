package com.example;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.PlaybackParameters;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionCommand;
import androidx.media3.session.SessionToken;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.audio.AudioFxEngine;
import com.example.audio.NeonAudioService;
import com.example.data.AudioLibraryRepository;
import com.example.data.PlaylistRepository;
import com.example.model.EqPreset;
import com.example.model.Playlist;
import com.example.model.Track;
import com.example.ui.adapter.PresetAdapter;
import com.example.ui.adapter.TrackAdapter;
import com.example.ui.theme.AlbumColorExtractor;
import com.example.ui.theme.DynamicThemeRenderer;
import com.example.ui.theme.NeonPalette;
import com.example.ui.theme.PlayerUiStyleController;
import com.example.ui.theme.UiStyleMode;
import com.example.ui.theme.UiStylePreferences;
import com.example.ui.theme.UiStyleSwitcherSheet;
import com.example.ui.views.NeonEqualizerView;
import com.example.ui.views.NeonWaveformView;
import com.example.util.DeviceResourceOptimizer;
import com.example.util.LrcParser;
import com.example.util.PermissionHelper;
import com.example.util.TimeFormatter;
import com.example.widget.NeonWaveWidgetProvider;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.imageview.ShapeableImageView;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.common.util.concurrent.ListenableFuture;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private enum FilterTab { ALL, FAVORITES, RECENT, PLAYLISTS, FORMATS, FOLDERS }
    private enum SortMode {
        NEWEST("Newest"),
        TITLE("A–Z"),
        ARTIST("Artist"),
        DURATION("Length"),
        FORMAT("Format");

        final String label;
        SortMode(String label) { this.label = label; }
    }

    private AudioLibraryRepository repository;
    private PlaylistRepository playlistRepository;
    private AudioFxEngine fxEngine;
    private DeviceResourceOptimizer resourceOptimizer;
    private final DeviceResourceOptimizer.OptimizerListener optimizerListener =
            tier -> runOnUiThread(this::applyAdaptiveOptimizationProfile);

    private View rootScroll;
    private View heroPlayerCard;
    private View cardEqPresets;
    private View cardAudioFrequency;
    private View cardUpNext;
    private TextView badgeBrandSubtitle;
    private TextView badgeEqMode;

    private ShapeableImageView heroAlbumArt;
    private TextView heroTrackTitle;
    private TextView heroTrackArtist;
    private TextView heroQualityBadge;
    private TextView heroBitrateBadge;
    private TextView btnHeroLyrics;
    private TextView btnAbLoop;
    private ImageButton btnFavorite;
    private ImageButton btnMoreOptions;

    private NeonWaveformView waveformView;
    private SeekBar seekBarProgress;
    private TextView textCurrentTime;
    private TextView textTotalTime;

    private ImageButton btnShuffle;
    private ImageButton btnPrev;
    private ImageButton btnPlayPause;
    private ImageButton btnNext;
    private ImageButton btnRepeat;

    private MaterialSwitch switchEqEnabled;
    private RecyclerView recyclerPresets;
    private PresetAdapter presetAdapter;
    private NeonEqualizerView equalizerView;

    private TextView btnSortTracks;
    private TextView btnFilterAll;
    private TextView btnFilterFavorites;
    private TextView btnFilterRecent;
    private TextView btnFilterPlaylists;
    private TextView btnFilterFormats;
    private TextView btnFilterFolders;
    private HorizontalScrollView subFilterScroll;
    private LinearLayout subFilterContainer;
    private ImageButton btnToggleSearch;
    private EditText editSearch;
    private View emptyStateContainer;
    private TextView emptyStateTitle;
    private TextView emptyStateSubtitle;
    private MaterialButton btnGrantPermissions;
    private MaterialButton btnEmptyPickFiles;
    private RecyclerView recyclerTracks;
    private TrackAdapter trackAdapter;

    private ListenableFuture<MediaController> controllerFuture;
    private MediaController mediaController;

    private final List<Track> allTracks = new ArrayList<>();
    private final List<Track> displayedTracks = new ArrayList<>();
    private Track activeTrack = null;

    private FilterTab activeFilterTab = FilterTab.ALL;
    private String selectedSubFilter = null;
    private SortMode activeSortMode = SortMode.NEWEST;
    private String searchQuery = "";
    private boolean isUserSeeking = false;
    private boolean restoredLastSession = false;

    private float currentPlaybackSpeed = 1.0f;
    private float currentPlaybackPitch = 1.0f;
    private int sleepMinutesSelected = 0;

    // A-B Loop segment state
    private long loopStartMs = -1L;
    private long loopEndMs = -1L;

    // Dynamic album-art NeonWave theme state
    private NeonPalette currentPalette = NeonPalette.DEFAULT;
    private ValueAnimator themeAnimator;
    private Bitmap currentAlbumBitmap = null;
    private final ExecutorService paletteExecutor = Executors.newSingleThreadExecutor();

    // Multi-interface theme switcher & controller
    private UiStylePreferences uiStylePreferences;
    private PlayerUiStyleController uiStyleController;

    // Live Lyrics dialog state
    private BottomSheetDialog activeLyricsDialog;
    private String activeLyricsTrackId;
    private List<LrcParser.LyricLine> activeLyricLines = new ArrayList<>();
    private LinearLayout activeLyricsContainer;
    private ScrollView activeLyricsScroll;
    private int lastHighlightedLyricIdx = -2;
    private Track pendingLrcTargetTrack;

    // Track queue & UI update caches to avoid redundant Binder IPC and layout passes
    private final List<String> queuedTrackIds = new ArrayList<>();
    private long lastProgressDurMs = -1L;
    private long lastProgressTotalSec = -1L;
    private long lastProgressPosSec = -1L;
    private int lastRepeatIconRes = 0;
    private int lastAbLoopState = -1;
    private boolean hasRequestedAudioPermissionOnce = false;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressRunnable = new Runnable() {
        @Override
        public void run() {
            updatePlaybackProgress();
            updateActiveLyricsHighlight();
            boolean playing = mediaController != null && mediaController.isPlaying();
            long interval = resourceOptimizer != null
                    ? resourceOptimizer.getProgressPollIntervalMs(playing)
                    : (playing ? 250L : 800L);
            mainHandler.postDelayed(this, interval);
        }
    };
    private final Runnable sleepTimerRunnable = () -> {
        sleepMinutesSelected = 0;
        if (mediaController != null && mediaController.isPlaying()) {
            mediaController.pause();
            Toast.makeText(MainActivity.this, R.string.sheet_sleep_timer, Toast.LENGTH_SHORT).show();
        }
    };

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                hasRequestedAudioPermissionOnce = true;
                refreshLibrary(false);
                if (PermissionHelper.hasRecordAudioPermission(this)) {
                    fxEngine.ensureVisualizerAttached(this);
                }
            });

    private final ActivityResultLauncher<String[]> pickAudioLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenMultipleDocuments(), uris -> {
                if (uris != null && !uris.isEmpty()) {
                    repository.addImportedUris(uris);
                    refreshLibraryAndSelectUri(uris.get(0));
                }
            });

    private final ActivityResultLauncher<String[]> pickLrcLauncher =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null && pendingLrcTargetTrack != null) {
                    String loaded = readTextFromUri(uri);
                    if (loaded != null && !loaded.trim().isEmpty()) {
                        repository.saveCustomLyrics(pendingLrcTargetTrack.getId(), loaded);
                        if (activeLyricsDialog != null && activeLyricsDialog.isShowing()) {
                            renderLyricsLines(loaded);
                        }
                        Toast.makeText(this, "Lyrics loaded", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EdgeToEdge.enable(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repository = new AudioLibraryRepository(this);
        playlistRepository = new PlaylistRepository(this);
        fxEngine = AudioFxEngine.getInstance();
        fxEngine.init(this);
        resourceOptimizer = DeviceResourceOptimizer.getInstance(this);
        resourceOptimizer.addListener(optimizerListener);
        uiStylePreferences = new UiStylePreferences(this);

        applyWindowInsets();
        bindViews();
        setupEqualizerSection();
        setupLibrarySection();
        setupTransportControls();
        setupUiStyleController();
        applyAdaptiveOptimizationProfile();

        requestInitialPermissionsIfNeeded();
        refreshLibrary();
        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(@NonNull Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void applyWindowInsets() {
        View container = findViewById(R.id.main_content_container);
        final int baseLeft = container.getPaddingLeft();
        final int baseTop = container.getPaddingTop();
        final int baseRight = container.getPaddingRight();
        final int baseBottom = container.getPaddingBottom();

        View miniBar = findViewById(R.id.floating_mini_docked_card);
        final int miniBaseBottomMargin = miniBar != null && miniBar.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams
                ? ((android.view.ViewGroup.MarginLayoutParams) miniBar.getLayoutParams()).bottomMargin
                : 0;

        View rootFrame = findViewById(R.id.root_frame);
        ViewCompat.setOnApplyWindowInsetsListener(rootFrame != null ? rootFrame : container, (v, insets) -> {
            Insets sysBars = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            container.setPadding(
                    baseLeft + sysBars.left,
                    baseTop + sysBars.top,
                    baseRight + sysBars.right,
                    baseBottom + sysBars.bottom
            );
            if (miniBar != null && miniBar.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams) {
                android.view.ViewGroup.MarginLayoutParams mlp =
                        (android.view.ViewGroup.MarginLayoutParams) miniBar.getLayoutParams();
                mlp.bottomMargin = miniBaseBottomMargin + sysBars.bottom;
                miniBar.setLayoutParams(mlp);
            }
            return insets;
        });
    }

    private void bindViews() {
        rootScroll = findViewById(R.id.root_scroll);
        heroPlayerCard = findViewById(R.id.hero_player_card);
        cardEqPresets = findViewById(R.id.card_eq_presets);
        cardAudioFrequency = findViewById(R.id.card_audio_frequency);
        cardUpNext = findViewById(R.id.card_up_next);
        badgeBrandSubtitle = findViewById(R.id.badge_brand_subtitle);
        badgeEqMode = findViewById(R.id.badge_eq_mode);

        heroAlbumArt = findViewById(R.id.hero_album_art);
        heroTrackTitle = findViewById(R.id.hero_track_title);
        heroTrackTitle.setSelected(true);
        heroTrackArtist = findViewById(R.id.hero_track_artist);
        heroQualityBadge = findViewById(R.id.hero_quality_badge);
        heroBitrateBadge = findViewById(R.id.hero_bitrate_badge);
        btnHeroLyrics = findViewById(R.id.btn_hero_lyrics);
        btnAbLoop = findViewById(R.id.btn_ab_loop);
        btnFavorite = findViewById(R.id.btn_favorite);
        btnMoreOptions = findViewById(R.id.btn_more_options);

        waveformView = findViewById(R.id.neon_waveform_view);
        seekBarProgress = findViewById(R.id.seek_bar_progress);
        textCurrentTime = findViewById(R.id.text_current_time);
        textTotalTime = findViewById(R.id.text_total_time);

        btnShuffle = findViewById(R.id.btn_shuffle);
        btnPrev = findViewById(R.id.btn_prev);
        btnPlayPause = findViewById(R.id.btn_play_pause);
        btnNext = findViewById(R.id.btn_next);
        btnRepeat = findViewById(R.id.btn_repeat);

        switchEqEnabled = findViewById(R.id.switch_eq_enabled);
        recyclerPresets = findViewById(R.id.recycler_presets);
        equalizerView = findViewById(R.id.neon_equalizer_view);

        btnSortTracks = findViewById(R.id.btn_sort_tracks);
        btnFilterAll = findViewById(R.id.btn_filter_all);
        btnFilterFavorites = findViewById(R.id.btn_filter_favorites);
        btnFilterRecent = findViewById(R.id.btn_filter_recent);
        btnFilterPlaylists = findViewById(R.id.btn_filter_playlists);
        btnFilterFormats = findViewById(R.id.btn_filter_formats);
        btnFilterFolders = findViewById(R.id.btn_filter_folders);
        subFilterScroll = findViewById(R.id.sub_filter_scroll);
        subFilterContainer = findViewById(R.id.sub_filter_container);
        btnToggleSearch = findViewById(R.id.btn_toggle_search);
        editSearch = findViewById(R.id.edit_search);
        emptyStateContainer = findViewById(R.id.empty_state_container);
        emptyStateTitle = findViewById(R.id.empty_state_title);
        emptyStateSubtitle = findViewById(R.id.empty_state_subtitle);
        btnGrantPermissions = findViewById(R.id.btn_grant_permissions);
        btnEmptyPickFiles = findViewById(R.id.btn_empty_pick_files);
        recyclerTracks = findViewById(R.id.recycler_tracks);

        findViewById(R.id.btn_pick_files).setOnClickListener(v -> launchAudioFilePicker());
        findViewById(R.id.btn_rescan).setOnClickListener(v -> {
            if (!PermissionHelper.hasAudioReadPermission(this)) {
                requestAudioLibraryPermissions();
            } else {
                refreshLibrary(true);
            }
        });

        waveformView.setOnClickListener(v -> {
            NeonWaveformView.VisualMode mode = waveformView.cycleVisualMode();
            Toast.makeText(this, mode.displayName, Toast.LENGTH_SHORT).show();
        });

        btnHeroLyrics.setOnClickListener(v -> {
            if (activeTrack != null) {
                showLyricsDialog(activeTrack);
            } else {
                Toast.makeText(this, R.string.default_track_artist, Toast.LENGTH_SHORT).show();
            }
        });

        btnAbLoop.setOnClickListener(v -> handleAbLoopTap());
        updateAbLoopUi();
    }

    private void setupEqualizerSection() {
        switchEqEnabled.setChecked(fxEngine.isEqEnabled());
        equalizerView.setEqEnabled(fxEngine.isEqEnabled());
        equalizerView.setBandsDb(fxEngine.getUiBandGainsDb());

        presetAdapter = new PresetAdapter(preset -> {
            fxEngine.applyPreset(preset);
            presetAdapter.setSelectedPreset(preset);
            equalizerView.setBandsDb(fxEngine.getUiBandGainsDb());
            if (!switchEqEnabled.isChecked()) {
                switchEqEnabled.setChecked(true);
            }
        });
        presetAdapter.setSelectedPreset(fxEngine.getCurrentPreset());
        recyclerPresets.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerPresets.setAdapter(presetAdapter);

        switchEqEnabled.setOnCheckedChangeListener((buttonView, isChecked) -> {
            fxEngine.setEqEnabled(isChecked);
            equalizerView.setEqEnabled(isChecked);
            syncAudioServicePrefs();
        });

        equalizerView.setOnBandChangedListener((bandIndex, gainDb) -> {
            fxEngine.setUiBandGainDb(bandIndex, gainDb);
            presetAdapter.setSelectedPreset(EqPreset.CUSTOM);
            if (!switchEqEnabled.isChecked()) {
                switchEqEnabled.setChecked(true);
            }
        });
    }

    private void setupLibrarySection() {
        trackAdapter = new TrackAdapter(repository, new TrackAdapter.OnTrackClickListener() {
            @Override
            public void onTrackClicked(Track track, int position) {
                playTrackAtDisplayedPosition(position);
            }

            @Override
            public void onTrackMoreClicked(Track track, View anchorView) {
                showTrackContextMenu(track, anchorView);
            }
        });
        recyclerTracks.setLayoutManager(new LinearLayoutManager(this));
        recyclerTracks.setItemViewCacheSize(12);
        recyclerTracks.setAdapter(trackAdapter);

        btnFilterAll.setOnClickListener(v -> selectFilterTab(FilterTab.ALL));
        btnFilterFavorites.setOnClickListener(v -> selectFilterTab(FilterTab.FAVORITES));
        btnFilterRecent.setOnClickListener(v -> selectFilterTab(FilterTab.RECENT));
        btnFilterPlaylists.setOnClickListener(v -> selectFilterTab(FilterTab.PLAYLISTS));
        btnFilterFormats.setOnClickListener(v -> selectFilterTab(FilterTab.FORMATS));
        btnFilterFolders.setOnClickListener(v -> selectFilterTab(FilterTab.FOLDERS));

        btnSortTracks.setOnClickListener(v -> {
            SortMode[] modes = SortMode.values();
            activeSortMode = modes[(activeSortMode.ordinal() + 1) % modes.length];
            btnSortTracks.setText(getString(R.string.sort_label) + ": " + activeSortMode.label);
            applyFilterAndRender();
        });

        btnToggleSearch.setOnClickListener(v -> {
            boolean show = editSearch.getVisibility() != View.VISIBLE;
            editSearch.setVisibility(show ? View.VISIBLE : View.GONE);
            if (!show) {
                editSearch.setText("");
                searchQuery = "";
                applyFilterAndRender();
            } else {
                editSearch.requestFocus();
            }
        });

        editSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchQuery = s != null ? s.toString().trim().toLowerCase(Locale.US) : "";
                applyFilterAndRender();
            }
            @Override public void afterTextChanged(Editable s) {}
        });

        btnGrantPermissions.setOnClickListener(v -> requestAudioLibraryPermissions());
        btnEmptyPickFiles.setOnClickListener(v -> launchAudioFilePicker());
    }

    private void selectFilterTab(FilterTab tab) {
        activeFilterTab = tab;
        selectedSubFilter = null;
        updateFilterTabsUi();
        rebuildSubFilterChips();
        applyFilterAndRender();
    }

    private void updateFilterTabsUi() {
        TextView[] tabs = {
                btnFilterAll, btnFilterFavorites, btnFilterRecent,
                btnFilterPlaylists, btnFilterFormats, btnFilterFolders
        };
        FilterTab[] enums = FilterTab.values();
        int secondaryText = uiStyleController != null
                ? uiStyleController.getSecondaryTextColorForTabs()
                : ContextCompat.getColor(this, R.color.text_secondary);
        int activeText = uiStyleController != null
                ? uiStyleController.getAccentTextColorForTabs()
                : currentPalette.secondaryNeon;
        for (int i = 0; i < tabs.length; i++) {
            boolean active = enums[i] == activeFilterTab;
            Object prev = tabs[i].getTag();
            if (!(prev instanceof Boolean) || ((Boolean) prev) != active) {
                tabs[i].setTag(active);
                tabs[i].setBackgroundResource(active ? R.drawable.bg_pill_badge : 0);
            }
            tabs[i].setTextColor(active ? activeText : secondaryText);
        }
    }

    private void rebuildSubFilterChips() {
        subFilterContainer.removeAllViews();
        if (activeFilterTab == FilterTab.FORMATS) {
            Set<String> formats = new LinkedHashSet<>();
            for (Track t : allTracks) {
                if (t.getFormat() != null) formats.add(t.getFormat());
            }
            if (formats.isEmpty()) {
                subFilterScroll.setVisibility(View.GONE);
                return;
            }
            if (selectedSubFilter == null) selectedSubFilter = formats.iterator().next();
            subFilterScroll.setVisibility(View.VISIBLE);
            for (String fmt : formats) {
                addSubChip(fmt, fmt.equals(selectedSubFilter), () -> {
                    selectedSubFilter = fmt;
                    rebuildSubFilterChips();
                    applyFilterAndRender();
                }, null);
            }
        } else if (activeFilterTab == FilterTab.FOLDERS) {
            Set<String> folders = new LinkedHashSet<>();
            for (Track t : allTracks) {
                folders.add(t.getFolderName());
            }
            if (folders.isEmpty()) {
                subFilterScroll.setVisibility(View.GONE);
                return;
            }
            if (selectedSubFilter == null) selectedSubFilter = folders.iterator().next();
            subFilterScroll.setVisibility(View.VISIBLE);
            for (String folder : folders) {
                addSubChip(folder, folder.equals(selectedSubFilter), () -> {
                    selectedSubFilter = folder;
                    rebuildSubFilterChips();
                    applyFilterAndRender();
                }, null);
            }
        } else if (activeFilterTab == FilterTab.PLAYLISTS) {
            subFilterScroll.setVisibility(View.VISIBLE);
            addSubChip(getString(R.string.btn_new_playlist), false, () -> showCreatePlaylistDialog(null), null);

            List<Playlist> playlists = playlistRepository.getPlaylists();
            if (!playlists.isEmpty() && selectedSubFilter == null) {
                selectedSubFilter = playlists.get(0).getId();
            }
            for (Playlist pl : playlists) {
                addSubChip(
                        pl.getName() + " (" + pl.getTrackIds().size() + ")",
                        pl.getId().equals(selectedSubFilter),
                        () -> {
                            selectedSubFilter = pl.getId();
                            rebuildSubFilterChips();
                            applyFilterAndRender();
                        },
                        () -> {
                            new AlertDialog.Builder(this)
                                    .setTitle(pl.getName())
                                    .setMessage("Delete this playlist?")
                                    .setPositiveButton("Delete", (d, w) -> {
                                        playlistRepository.deletePlaylist(pl.getId());
                                        if (pl.getId().equals(selectedSubFilter)) selectedSubFilter = null;
                                        rebuildSubFilterChips();
                                        applyFilterAndRender();
                                    })
                                    .setNegativeButton("Cancel", null)
                                    .show();
                        }
                );
            }
        } else {
            subFilterScroll.setVisibility(View.GONE);
        }
    }

    private void addSubChip(String label, boolean selected, Runnable onClick, Runnable onLongClick) {
        float d = getResources().getDisplayMetrics().density;
        TextView chip = new TextView(this);
        chip.setText(label);
        chip.setTextSize(11.5f);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(Math.round(34 * d));
        chip.setPadding(Math.round(12 * d), 0, Math.round(12 * d), 0);
        chip.setBackgroundResource(selected ? R.drawable.bg_preset_tile_selected : R.drawable.bg_preset_tile_normal);
        chip.setTextColor(ContextCompat.getColor(this, selected ? R.color.neon_cyan : R.color.text_secondary));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(Math.round(6 * d));
        chip.setLayoutParams(lp);
        chip.setOnClickListener(v -> onClick.run());
        if (onLongClick != null) {
            chip.setOnLongClickListener(v -> {
                onLongClick.run();
                return true;
            });
        }
        subFilterContainer.addView(chip);
    }

    private void setupTransportControls() {
        btnPlayPause.setOnClickListener(v -> togglePlayPause());
        btnNext.setOnClickListener(v -> skipNext());
        btnPrev.setOnClickListener(v -> skipPrev());
        btnShuffle.setOnClickListener(v -> toggleShuffle());
        btnRepeat.setOnClickListener(v -> cycleRepeatMode());
        btnFavorite.setOnClickListener(v -> toggleActiveFavorite());
        btnMoreOptions.setOnClickListener(v -> showOptionsBottomSheet());

        seekBarProgress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    textCurrentTime.setText(TimeFormatter.formatDuration(progress));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                isUserSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                isUserSeeking = false;
                if (mediaController != null) {
                    mediaController.seekTo(seekBar.getProgress());
                }
            }
        });
    }

    private void setupUiStyleController() {
        uiStyleController = new PlayerUiStyleController(
                this,
                uiStylePreferences,
                repository,
                fxEngine,
                new PlayerUiStyleController.ActionsCallback() {
                    @Override public void onPlayPauseClicked() { togglePlayPause(); }
                    @Override public void onNextClicked() { skipNext(); }
                    @Override public void onPrevClicked() { skipPrev(); }
                    @Override public void onShuffleClicked() { toggleShuffle(); }
                    @Override public void onRepeatClicked() { cycleRepeatMode(); }
                    @Override public void onFavoriteClicked() { toggleActiveFavorite(); }
                    @Override public void onMoreOptionsClicked() { showOptionsBottomSheet(); }
                    @Override public void onSeekTo(int positionMs) {
                        if (mediaController != null) {
                            mediaController.seekTo(positionMs);
                        }
                    }
                    @Override public void onUserSeekingChanged(boolean seeking) {
                        isUserSeeking = seeking;
                    }
                    @Override public void onFloatingCollapsedChanged(boolean collapsed) {
                        updatePlaybackProgress();
                    }
                    @Override public void onTrebleKnobChanged(int treblePercent) {
                        float gainDb = AudioFxEngine.MIN_GAIN_DB
                                + (treblePercent / 100f) * (AudioFxEngine.MAX_GAIN_DB - AudioFxEngine.MIN_GAIN_DB);
                        fxEngine.setUiBandGainDb(8, gainDb);
                        fxEngine.setUiBandGainDb(9, gainDb);
                        equalizerView.setBandsDb(fxEngine.getUiBandGainsDb());
                        presetAdapter.setSelectedPreset(EqPreset.CUSTOM);
                        if (!switchEqEnabled.isChecked()) {
                            switchEqEnabled.setChecked(true);
                        }
                    }
                    @Override public void onUiStyleButtonClicked() {
                        openUiStyleStudio();
                    }
                }
        );
        uiStyleController.bindViews(trackAdapter, presetAdapter, equalizerView);
        uiStyleController.applyMode(uiStylePreferences.getActiveStyle(), false);
    }

    private void openUiStyleStudio() {
        UiStyleSwitcherSheet.show(
                this,
                uiStylePreferences.getActiveStyle(),
                uiStyleController.isFloatingCollapsed(),
                uiStyleController.isShowEqDeck(),
                new UiStyleSwitcherSheet.OnStudioActionListener() {
                    @Override
                    public void onPreviewStyle(UiStyleMode mode) {
                        uiStyleController.applyMode(mode, false);
                        updateFilterTabsUi();
                        updateShuffleAndRepeatUi();
                    }

                    @Override
                    public void onAssignStyle(UiStyleMode mode) {
                        uiStyleController.applyMode(mode, true);
                        updateFilterTabsUi();
                        updateShuffleAndRepeatUi();
                    }

                    @Override
                    public void onToggleFloatingCollapsed(boolean collapsed) {
                        uiStyleController.setFloatingCollapsed(collapsed);
                    }

                    @Override
                    public void onToggleShowEqDeck(boolean showEq) {
                        uiStyleController.setShowEqDeck(showEq);
                    }

                    @Override
                    public void onOpenAudioFxStudio() {
                        showOptionsBottomSheet();
                    }
                }
        );
    }

    private void togglePlayPause() {
        if (mediaController == null) return;
        if (mediaController.getMediaItemCount() == 0) {
            if (!displayedTracks.isEmpty()) {
                playTrackAtDisplayedPosition(0);
            } else {
                launchAudioFilePicker();
            }
            return;
        }
        if (mediaController.isPlaying()) {
            mediaController.pause();
        } else {
            if (mediaController.getPlaybackState() == Player.STATE_ENDED) {
                mediaController.seekTo(0);
            }
            mediaController.play();
        }
    }

    private void skipNext() {
        if (mediaController != null && mediaController.hasNextMediaItem()) {
            mediaController.seekToNextMediaItem();
            mediaController.play();
        }
    }

    private void skipPrev() {
        if (mediaController == null) return;
        if (mediaController.getCurrentPosition() > 3500L) {
            mediaController.seekTo(0);
        } else if (mediaController.hasPreviousMediaItem()) {
            mediaController.seekToPreviousMediaItem();
            mediaController.play();
        }
    }

    private void toggleShuffle() {
        if (mediaController != null) {
            boolean next = !mediaController.getShuffleModeEnabled();
            mediaController.setShuffleModeEnabled(next);
            updateShuffleAndRepeatUi();
        }
    }

    private void cycleRepeatMode() {
        if (mediaController == null) return;
        int current = mediaController.getRepeatMode();
        int next;
        if (current == Player.REPEAT_MODE_OFF) next = Player.REPEAT_MODE_ALL;
        else if (current == Player.REPEAT_MODE_ALL) next = Player.REPEAT_MODE_ONE;
        else next = Player.REPEAT_MODE_OFF;
        mediaController.setRepeatMode(next);
        updateShuffleAndRepeatUi();
    }

    private void toggleActiveFavorite() {
        if (activeTrack == null) return;
        boolean nowFav = repository.toggleFavorite(activeTrack);
        updateFavoriteButton(nowFav);
        if (activeFilterTab == FilterTab.FAVORITES) {
            applyFilterAndRender();
        }
    }

    private void requestInitialPermissionsIfNeeded() {
        String[] missing = PermissionHelper.getAllMissingPermissions(this, false);
        if (missing.length > 0) {
            permissionLauncher.launch(missing);
        }
    }

    private void requestAudioLibraryPermissions() {
        String audioPerm = PermissionHelper.getAudioReadPermission();
        if (!PermissionHelper.hasAudioReadPermission(this)
                && hasRequestedAudioPermissionOnce
                && !shouldShowRequestPermissionRationale(audioPerm)) {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null));
            startActivity(intent);
            return;
        }
        String[] missing = PermissionHelper.getAllMissingPermissions(this, false);
        if (missing.length > 0) {
            permissionLauncher.launch(missing);
        } else {
            refreshLibrary(true);
        }
    }

    private void requestPermissionsWithVisualizer() {
        String[] missing = PermissionHelper.getAllMissingPermissions(this, true);
        if (missing.length > 0) {
            permissionLauncher.launch(missing);
        } else {
            refreshLibrary(false);
        }
    }

    private void launchAudioFilePicker() {
        pickAudioLauncher.launch(new String[]{
                "audio/*",
                "application/ogg",
                "application/x-flac",
                "application/octet-stream"
        });
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            Uri uri = intent.getData();
            Track externalTrack = repository.createTrackFromExternalUri(uri);
            if (externalTrack != null) {
                refreshLibraryAndSelectUri(uri);
            }
        }
    }

    private void refreshLibrary() {
        refreshLibraryAndSelectUri(null, false);
    }

    private void refreshLibrary(boolean showCountToast) {
        refreshLibraryAndSelectUri(null, showCountToast);
    }

    private void refreshLibraryAndSelectUri(Uri uriToPlayImmediately) {
        refreshLibraryAndSelectUri(uriToPlayImmediately, false);
    }

    private void refreshLibraryAndSelectUri(Uri uriToPlayImmediately, boolean showCountToast) {
        repository.loadAllTracks(tracks -> {
            allTracks.clear();
            allTracks.addAll(tracks);
            queuedTrackIds.clear();
            rebuildSubFilterChips();
            applyFilterAndRender();

            if (showCountToast) {
                Toast.makeText(
                        this,
                        getString(R.string.rescan_tracks_found, allTracks.size()),
                        Toast.LENGTH_SHORT
                ).show();
            }

            if (uriToPlayImmediately != null) {
                for (int i = 0; i < displayedTracks.size(); i++) {
                    if (uriToPlayImmediately.equals(displayedTracks.get(i).getUri())) {
                        playTrackAtDisplayedPosition(i);
                        return;
                    }
                }
            } else if (!restoredLastSession && activeTrack == null && !allTracks.isEmpty()) {
                restoredLastSession = true;
                String lastId = repository.getLastTrackId();
                Track target = allTracks.get(0);
                if (lastId != null) {
                    for (Track t : allTracks) {
                        if (t.getId().equals(lastId)) {
                            target = t;
                            break;
                        }
                    }
                }
                bindHeroTrack(target);
                long savedPos = repository.getLastPositionMs();
                if (lastId != null && lastId.equals(target.getId()) && savedPos > 0) {
                    seekBarProgress.setProgress((int) savedPos);
                    textCurrentTime.setText(TimeFormatter.formatDuration(savedPos));
                }
            }
        });
    }

    private void applyFilterAndRender() {
        displayedTracks.clear();

        if (activeFilterTab == FilterTab.RECENT) {
            List<String> recentIds = repository.getRecentTrackIds();
            for (String id : recentIds) {
                for (Track t : allTracks) {
                    if (t.getId().equals(id) && matchesSearch(t)) {
                        displayedTracks.add(t);
                        break;
                    }
                }
            }
        } else {
            List<String> activePlaylistIds = null;
            if (activeFilterTab == FilterTab.PLAYLISTS && selectedSubFilter != null) {
                for (Playlist pl : playlistRepository.getPlaylists()) {
                    if (pl.getId().equals(selectedSubFilter)) {
                        activePlaylistIds = pl.getTrackIds();
                        break;
                    }
                }
            }

            for (Track track : allTracks) {
                if (activeFilterTab == FilterTab.FAVORITES && !track.isFavorite()) continue;
                if (activeFilterTab == FilterTab.FORMATS && selectedSubFilter != null
                        && !selectedSubFilter.equalsIgnoreCase(track.getFormat())) continue;
                if (activeFilterTab == FilterTab.FOLDERS && selectedSubFilter != null
                        && !selectedSubFilter.equals(track.getFolderName())) continue;
                if (activeFilterTab == FilterTab.PLAYLISTS) {
                    if (activePlaylistIds == null || !activePlaylistIds.contains(track.getId())) continue;
                }
                if (!matchesSearch(track)) continue;
                displayedTracks.add(track);
            }

            sortDisplayedTracks();
        }

        trackAdapter.submitList(displayedTracks);
        updateRecyclerHeightForCount(displayedTracks.size());
        updateEmptyState();
    }

    private void updateRecyclerHeightForCount(int count) {
        if (recyclerTracks == null) return;
        android.view.ViewGroup.LayoutParams lp = recyclerTracks.getLayoutParams();
        if (lp == null) return;
        float density = getResources().getDisplayMetrics().density;
        int targetHeight = count <= 5
                ? android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                : Math.round(440 * density);
        boolean nested = count > 5;
        if (lp.height != targetHeight) {
            lp.height = targetHeight;
            recyclerTracks.setLayoutParams(lp);
        }
        recyclerTracks.setNestedScrollingEnabled(nested);
    }

    private boolean matchesSearch(Track track) {
        if (searchQuery.isEmpty()) return true;
        return track.getTitle().toLowerCase(Locale.US).contains(searchQuery)
                || track.getArtist().toLowerCase(Locale.US).contains(searchQuery)
                || track.getFormat().toLowerCase(Locale.US).contains(searchQuery)
                || track.getFolderName().toLowerCase(Locale.US).contains(searchQuery);
    }

    private void sortDisplayedTracks() {
        if (activeSortMode == SortMode.TITLE) {
            Collections.sort(displayedTracks, (a, b) -> a.getTitle().compareToIgnoreCase(b.getTitle()));
        } else if (activeSortMode == SortMode.ARTIST) {
            Collections.sort(displayedTracks, (a, b) -> a.getArtist().compareToIgnoreCase(b.getArtist()));
        } else if (activeSortMode == SortMode.DURATION) {
            Collections.sort(displayedTracks, (a, b) -> Long.compare(b.getDurationMs(), a.getDurationMs()));
        } else if (activeSortMode == SortMode.FORMAT) {
            Collections.sort(displayedTracks, (a, b) -> a.getFormat().compareToIgnoreCase(b.getFormat()));
        } else {
            Collections.sort(displayedTracks, (a, b) -> Long.compare(b.getDateAddedSec(), a.getDateAddedSec()));
        }
    }

    private void updateEmptyState() {
        if (!displayedTracks.isEmpty()) {
            emptyStateContainer.setVisibility(View.GONE);
            recyclerTracks.setVisibility(View.VISIBLE);
            return;
        }
        recyclerTracks.setVisibility(View.GONE);
        emptyStateContainer.setVisibility(View.VISIBLE);

        if (!PermissionHelper.hasAudioReadPermission(this)) {
            emptyStateTitle.setText(R.string.permission_title);
            emptyStateSubtitle.setText(R.string.permission_subtitle);
            btnGrantPermissions.setVisibility(View.VISIBLE);
        } else {
            emptyStateTitle.setText(R.string.empty_library_title);
            emptyStateSubtitle.setText(R.string.empty_library_subtitle);
            btnGrantPermissions.setVisibility(View.GONE);
        }
    }

    private void playTrackAtDisplayedPosition(int position) {
        if (position < 0 || position >= displayedTracks.size()) return;
        Track clicked = displayedTracks.get(position);

        if (mediaController != null && activeTrack != null
                && clicked.getId().equals(activeTrack.getId())
                && mediaController.getMediaItemCount() > 0) {
            if (mediaController.isPlaying()) {
                mediaController.pause();
            } else {
                mediaController.play();
            }
            return;
        }

        if (mediaController == null) {
            bindHeroTrack(clicked);
            return;
        }

        if (isQueuedListSyncedWithDisplayedTracks() && mediaController.getMediaItemCount() == displayedTracks.size()) {
            mediaController.seekToDefaultPosition(position);
            mediaController.setPlaybackParameters(new PlaybackParameters(currentPlaybackSpeed, currentPlaybackPitch));
            mediaController.play();
        } else {
            List<MediaItem> mediaItems = new ArrayList<>(displayedTracks.size());
            queuedTrackIds.clear();
            for (Track t : displayedTracks) {
                queuedTrackIds.add(t.getId());
                MediaMetadata.Builder meta = new MediaMetadata.Builder()
                        .setTitle(t.getTitle())
                        .setArtist(t.getArtist())
                        .setAlbumTitle(t.getAlbum());
                if (t.getAlbumArtUri() != null) {
                    meta.setArtworkUri(t.getAlbumArtUri());
                }
                mediaItems.add(new MediaItem.Builder()
                        .setMediaId(t.getId())
                        .setUri(t.getUri())
                        .setMediaMetadata(meta.build())
                        .build());
            }

            mediaController.setMediaItems(mediaItems, position, 0L);
            mediaController.prepare();
            mediaController.setPlaybackParameters(new PlaybackParameters(currentPlaybackSpeed, currentPlaybackPitch));
            mediaController.play();
        }
        resetAbLoop();
        bindHeroTrack(clicked);
        repository.recordRecentPlay(clicked.getId());
    }

    private boolean isQueuedListSyncedWithDisplayedTracks() {
        if (queuedTrackIds.size() != displayedTracks.size() || queuedTrackIds.isEmpty()) {
            return false;
        }
        for (int i = 0; i < displayedTracks.size(); i++) {
            if (!queuedTrackIds.get(i).equals(displayedTracks.get(i).getId())) {
                return false;
            }
        }
        return true;
    }

    private void bindHeroTrack(Track track) {
        if (track == null) return;
        boolean trackChanged = activeTrack == null || !track.getId().equals(activeTrack.getId());
        if (trackChanged) {
            resetAbLoop();
        }
        activeTrack = track;
        heroTrackTitle.setText(track.getTitle());
        heroTrackArtist.setText(track.getArtist());
        heroQualityBadge.setText(track.getQualityBadgeText());
        heroBitrateBadge.setText(track.getBitrateBadgeText());
        updateFavoriteButton(track.isFavorite());

        if (track.getDurationMs() > 0) {
            if (seekBarProgress.getMax() != (int) track.getDurationMs()) {
                seekBarProgress.setMax((int) track.getDurationMs());
            }
            textTotalTime.setText(TimeFormatter.formatDuration(track.getDurationMs()));
            lastProgressDurMs = track.getDurationMs();
            lastProgressTotalSec = track.getDurationMs() / 1000L;
        }
        lastProgressPosSec = -1L;

        if (uiStyleController != null) {
            uiStyleController.bindTrack(track, displayedTracks);
        }

        heroAlbumArt.setImageResource(R.drawable.img_default_album_art);
        currentAlbumBitmap = null;
        if (!fxEngine.isDynamicThemeEnabled()) {
            animateToPalette(NeonPalette.DEFAULT);
        }
        int sizePx = Math.round(96 * getResources().getDisplayMetrics().density);
        repository.loadAlbumArtAsync(track, sizePx, (trackId, bitmap) -> {
            if (activeTrack != null && trackId.equals(activeTrack.getId())) {
                if (bitmap != null && !bitmap.isRecycled()) {
                    heroAlbumArt.setImageBitmap(bitmap);
                    currentAlbumBitmap = bitmap;
                    if (uiStyleController != null) {
                        uiStyleController.onActiveAlbumBitmapLoaded(trackId, bitmap);
                    }
                    extractAndApplyDynamicTheme(trackId, bitmap);
                } else {
                    currentAlbumBitmap = null;
                    if (uiStyleController != null) {
                        uiStyleController.onActiveAlbumBitmapLoaded(trackId, null);
                    }
                    animateToPalette(NeonPalette.DEFAULT);
                }
            }
        });

        repository.enrichTrackDetailsAsync(track, enriched -> {
            if (activeTrack != null && enriched.getId().equals(activeTrack.getId())) {
                activeTrack = enriched;
                heroQualityBadge.setText(enriched.getQualityBadgeText());
                heroBitrateBadge.setText(enriched.getBitrateBadgeText());
            }
        });

        boolean playing = mediaController != null && mediaController.isPlaying();
        trackAdapter.setPlaybackState(track.getId(), playing);
        if (uiStyleController != null) {
            uiStyleController.updatePlayingState(playing);
        }
        NeonWaveWidgetProvider.updateAllWidgets(this, track.getTitle(), track.getArtist(), playing);
    }

    private void showTrackContextMenu(Track track, View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(0, 1, 0, R.string.btn_add_to_playlist);
        popup.getMenu().add(0, 2, 1, track.isFavorite() ? "Remove Favorite" : "Add to Favorites");
        popup.getMenu().add(0, 3, 2, R.string.btn_open_lyrics);
        popup.getMenu().add(0, 4, 3, R.string.btn_share_track);
        if (activeFilterTab == FilterTab.PLAYLISTS && selectedSubFilter != null) {
            popup.getMenu().add(0, 5, 4, "Remove from Playlist");
        } else if (track.isFromSaf()) {
            popup.getMenu().add(0, 6, 4, "Remove Imported File");
        }

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == 1) {
                showPlaylistPickerDialog(track);
            } else if (id == 2) {
                boolean nowFav = repository.toggleFavorite(track);
                if (activeTrack != null && activeTrack.getId().equals(track.getId())) {
                    updateFavoriteButton(nowFav);
                }
                applyFilterAndRender();
            } else if (id == 3) {
                showLyricsDialog(track);
            } else if (id == 4) {
                shareAudioTrack(track);
            } else if (id == 5 && selectedSubFilter != null) {
                playlistRepository.removeTrackFromPlaylist(selectedSubFilter, track.getId());
                rebuildSubFilterChips();
                applyFilterAndRender();
            } else if (id == 6) {
                repository.removeImportedUri(track.getId());
                refreshLibrary();
            }
            return true;
        });
        popup.show();
    }

    private void showPlaylistPickerDialog(Track track) {
        if (track == null) return;
        List<Playlist> playlists = playlistRepository.getPlaylists();
        String[] names = new String[playlists.size() + 1];
        for (int i = 0; i < playlists.size(); i++) {
            names[i] = playlists.get(i).getName();
        }
        names[playlists.size()] = getString(R.string.btn_new_playlist);

        new AlertDialog.Builder(this)
                .setTitle(R.string.btn_add_to_playlist)
                .setItems(names, (d, which) -> {
                    if (which == playlists.size()) {
                        showCreatePlaylistDialog(track);
                    } else {
                        Playlist chosen = playlists.get(which);
                        playlistRepository.addTrackToPlaylist(chosen.getId(), track.getId());
                        Toast.makeText(this, "Added to " + chosen.getName(), Toast.LENGTH_SHORT).show();
                        if (activeFilterTab == FilterTab.PLAYLISTS) {
                            rebuildSubFilterChips();
                        }
                    }
                })
                .show();
    }

    private void showCreatePlaylistDialog(Track trackToAdd) {
        EditText input = new EditText(this);
        input.setHint("Playlist name");
        input.setPadding(48, 32, 48, 24);
        new AlertDialog.Builder(this)
                .setTitle(R.string.btn_new_playlist)
                .setView(input)
                .setPositiveButton("Create", (d, w) -> {
                    Playlist created = playlistRepository.createPlaylist(input.getText().toString());
                    if (trackToAdd != null) {
                        playlistRepository.addTrackToPlaylist(created.getId(), trackToAdd.getId());
                    }
                    if (activeFilterTab == FilterTab.PLAYLISTS) {
                        selectedSubFilter = created.getId();
                        rebuildSubFilterChips();
                        applyFilterAndRender();
                    }
                    Toast.makeText(this, "Created " + created.getName(), Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void shareAudioTrack(Track track) {
        if (track == null) return;
        try {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType(track.getMimeType() != null ? track.getMimeType() : "audio/*");
            share.putExtra(Intent.EXTRA_STREAM, track.getUri());
            share.putExtra(Intent.EXTRA_SUBJECT, track.getTitle());
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, getString(R.string.btn_share_track)));
        } catch (Throwable e) {
            Toast.makeText(this, "Unable to share this track", Toast.LENGTH_SHORT).show();
        }
    }

    private void showLyricsDialog(Track track) {
        if (track == null) return;
        activeLyricsDialog = new BottomSheetDialog(this, R.style.NeonBottomSheetTheme);
        View view = getLayoutInflater().inflate(R.layout.dialog_lyrics, null);
        activeLyricsDialog.setContentView(view);

        ((TextView) view.findViewById(R.id.lyrics_track_title)).setText(track.getTitle());
        ((TextView) view.findViewById(R.id.lyrics_track_artist)).setText(track.getArtist());
        activeLyricsContainer = view.findViewById(R.id.lyrics_lines_container);
        activeLyricsScroll = view.findViewById(R.id.lyrics_scroll_view);
        activeLyricsTrackId = track.getId();
        lastHighlightedLyricIdx = -2;

        view.findViewById(R.id.btn_import_lrc).setOnClickListener(v -> {
            pendingLrcTargetTrack = track;
            pickLrcLauncher.launch(new String[]{"text/*", "application/octet-stream"});
        });

        view.findViewById(R.id.btn_paste_lyrics).setOnClickListener(v -> {
            EditText editor = new EditText(this);
            editor.setMinLines(6);
            editor.setHint("[00:12.00] Paste LRC or plain lyrics here...");
            editor.setPadding(40, 28, 40, 28);
            new AlertDialog.Builder(this)
                    .setTitle(R.string.btn_paste_lyrics)
                    .setView(editor)
                    .setPositiveButton("Save", (d, w) -> {
                        String text = editor.getText().toString();
                        repository.saveCustomLyrics(track.getId(), text);
                        renderLyricsLines(text);
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        });

        repository.loadLyricsAsync(track, (loadedId, rawLyrics) -> {
            if (loadedId.equals(activeLyricsTrackId) && activeLyricsDialog != null && activeLyricsDialog.isShowing()) {
                renderLyricsLines(rawLyrics);
            }
        });

        activeLyricsDialog.setOnDismissListener(d -> {
            activeLyricsContainer = null;
            activeLyricsScroll = null;
            activeLyricsTrackId = null;
        });
        activeLyricsDialog.show();
    }

    private void renderLyricsLines(String rawLyrics) {
        if (activeLyricsContainer == null) return;
        activeLyricsContainer.removeAllViews();
        activeLyricLines = LrcParser.parse(rawLyrics);
        lastHighlightedLyricIdx = -2;

        if (activeLyricLines.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(R.string.lyrics_empty_hint);
            empty.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            empty.setTextSize(13.5f);
            activeLyricsContainer.addView(empty);
            return;
        }

        for (LrcParser.LyricLine line : activeLyricLines) {
            TextView tv = new TextView(this);
            tv.setText(line.text);
            tv.setTextSize(15f);
            tv.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
            tv.setPadding(0, 10, 0, 10);
            if (line.timeMs >= 0) {
                tv.setOnClickListener(v -> {
                    if (mediaController != null && activeTrack != null && activeTrack.getId().equals(activeLyricsTrackId)) {
                        mediaController.seekTo(line.timeMs);
                    }
                });
            }
            activeLyricsContainer.addView(tv);
        }
        updateActiveLyricsHighlight();
    }

    private void updateActiveLyricsHighlight() {
        if (activeLyricsDialog == null || !activeLyricsDialog.isShowing()
                || activeLyricsContainer == null || activeLyricLines.isEmpty()
                || mediaController == null || activeTrack == null
                || !activeTrack.getId().equals(activeLyricsTrackId)) {
            return;
        }
        int activeIdx = LrcParser.findActiveLineIndex(activeLyricLines, mediaController.getCurrentPosition());
        if (activeIdx == lastHighlightedLyricIdx || activeIdx < 0) return;
        lastHighlightedLyricIdx = activeIdx;

        for (int i = 0; i < activeLyricsContainer.getChildCount(); i++) {
            View child = activeLyricsContainer.getChildAt(i);
            if (child instanceof TextView) {
                TextView tv = (TextView) child;
                boolean isCurrent = (i == activeIdx);
                tv.setTextColor(ContextCompat.getColor(
                        this, isCurrent ? R.color.neon_cyan : R.color.text_secondary));
                tv.setTextSize(isCurrent ? 17.5f : 15f);
                if (isCurrent && activeLyricsScroll != null) {
                    int targetY = Math.max(0, tv.getTop() - activeLyricsScroll.getHeight() / 3);
                    activeLyricsScroll.smoothScrollTo(0, targetY);
                }
            }
        }
    }

    private String readTextFromUri(Uri uri) {
        try (InputStream is = getContentResolver().openInputStream(uri)) {
            if (is == null) return null;
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } catch (Throwable ignored) {
            return null;
        }
    }

    private void updateFavoriteButton(boolean isFavorite) {
        btnFavorite.setImageResource(isFavorite ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        if (uiStyleController != null) {
            uiStyleController.updateFavoriteUi(isFavorite);
        }
    }

    private void updateShuffleAndRepeatUi() {
        if (mediaController == null) return;
        boolean shuffleOn = mediaController.getShuffleModeEnabled();
        btnShuffle.setColorFilter(shuffleOn
                ? currentPalette.secondaryNeon
                : ContextCompat.getColor(this, R.color.text_secondary));

        int repeatMode = mediaController.getRepeatMode();
        int desiredIcon = repeatMode == Player.REPEAT_MODE_ONE ? R.drawable.ic_repeat_one : R.drawable.ic_repeat;
        if (desiredIcon != lastRepeatIconRes) {
            lastRepeatIconRes = desiredIcon;
            btnRepeat.setImageResource(desiredIcon);
        }
        if (repeatMode == Player.REPEAT_MODE_ONE) {
            btnRepeat.setColorFilter(currentPalette.primaryNeon);
        } else if (repeatMode == Player.REPEAT_MODE_ALL) {
            btnRepeat.setColorFilter(currentPalette.secondaryNeon);
        } else {
            btnRepeat.setColorFilter(ContextCompat.getColor(this, R.color.text_secondary));
        }

        if (uiStyleController != null) {
            uiStyleController.updateShuffleAndRepeatUi(shuffleOn, repeatMode);
        }
    }

    private void extractAndApplyDynamicTheme(String trackId, Bitmap bitmap) {
        if (!fxEngine.isDynamicThemeEnabled() || bitmap == null || bitmap.isRecycled()) {
            animateToPalette(NeonPalette.DEFAULT);
            return;
        }
        paletteExecutor.execute(() -> {
            NeonPalette extracted = AlbumColorExtractor.extract(bitmap);
            mainHandler.post(() -> {
                if (!isFinishing() && !isDestroyed()
                        && activeTrack != null && trackId.equals(activeTrack.getId())
                        && fxEngine.isDynamicThemeEnabled()) {
                    animateToPalette(extracted);
                }
            });
        });
    }

    private void animateToPalette(NeonPalette target) {
        final NeonPalette safeTarget = target != null ? target : NeonPalette.DEFAULT;
        if (safeTarget.primaryNeon == currentPalette.primaryNeon
                && safeTarget.secondaryNeon == currentPalette.secondaryNeon
                && safeTarget.tertiaryGlow == currentPalette.tertiaryGlow
                && safeTarget.canvasStart == currentPalette.canvasStart) {
            return;
        }
        if (themeAnimator != null) {
            themeAnimator.cancel();
        }
        final NeonPalette start = currentPalette;
        trackAdapter.setThemePalette(safeTarget);
        presetAdapter.setThemePalette(safeTarget);
        waveformView.setPaletteColors(safeTarget.primaryNeon, safeTarget.secondaryNeon, safeTarget.tertiaryGlow);
        equalizerView.setPaletteColors(safeTarget.secondaryNeon, safeTarget.tertiaryGlow, safeTarget.primaryNeon);

        if (resourceOptimizer != null && !resourceOptimizer.shouldAnimateThemeTransitions()) {
            applyDynamicPalette(safeTarget, true);
            return;
        }

        themeAnimator = ValueAnimator.ofFloat(0f, 1f);
        themeAnimator.setDuration(380L);
        themeAnimator.addUpdateListener(anim -> {
            float frac = (float) anim.getAnimatedValue();
            applyDynamicPalette(NeonPalette.lerp(start, safeTarget, frac), false);
        });
        themeAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                applyDynamicPalette(safeTarget, true);
            }
        });
        themeAnimator.start();
    }

    private void applyDynamicPalette(NeonPalette palette, boolean updateChildControls) {
        currentPalette = palette != null ? palette : NeonPalette.DEFAULT;
        float density = getResources().getDisplayMetrics().density;

        boolean darkMode = uiStyleController == null || uiStyleController.getCurrentMode().isDarkCanvas;
        if (darkMode) {
            DynamicThemeRenderer.applyCosmicCanvas(rootScroll, currentPalette, density);
            DynamicThemeRenderer.applyHeroCard(heroPlayerCard, currentPalette, density);
            DynamicThemeRenderer.applySubCard(cardEqPresets, currentPalette, density);
            DynamicThemeRenderer.applySubCard(cardAudioFrequency, currentPalette, density);
            DynamicThemeRenderer.applySubCard(cardUpNext, currentPalette, density);
            DynamicThemeRenderer.applyPlayButton(btnPlayPause, currentPalette, density);
            DynamicThemeRenderer.applySeekBarColors(seekBarProgress, currentPalette);
            DynamicThemeRenderer.applyAlbumArtStroke(heroAlbumArt, currentPalette);
            DynamicThemeRenderer.applySwitchColors(switchEqEnabled, currentPalette);
            DynamicThemeRenderer.applySubtitlePill(this, badgeBrandSubtitle, currentPalette);
            DynamicThemeRenderer.applyAccentTextColor(badgeEqMode, currentPalette.secondaryNeon);
            DynamicThemeRenderer.applyAccentTextColor(btnHeroLyrics, currentPalette.secondaryNeon);
        }

        if (updateChildControls) {
            if (uiStyleController != null) {
                uiStyleController.applyDarkPalette(currentPalette, density);
            }
            updateShuffleAndRepeatUi();
            updateFilterTabsUi();
            updateAbLoopUi();
        }
    }

    private void handleAbLoopTap() {
        if (mediaController == null || activeTrack == null || mediaController.getMediaItemCount() == 0) {
            Toast.makeText(this, "Play a track first to set an A-B loop", Toast.LENGTH_SHORT).show();
            return;
        }
        long pos = Math.max(0L, mediaController.getCurrentPosition());
        if (loopStartMs < 0L) {
            loopStartMs = pos;
            loopEndMs = -1L;
            updateAbLoopUi();
        } else if (loopEndMs < 0L) {
            if (pos > loopStartMs + 300L) {
                loopEndMs = pos;
                mediaController.seekTo(loopStartMs);
                updateAbLoopUi();
            } else {
                Toast.makeText(this, "Seek past Point A first", Toast.LENGTH_SHORT).show();
            }
        } else {
            resetAbLoop();
        }
    }

    private void resetAbLoop() {
        loopStartMs = -1L;
        loopEndMs = -1L;
        updateAbLoopUi();
    }

    private void updateAbLoopUi() {
        if (btnAbLoop == null) return;
        float density = getResources().getDisplayMetrics().density;
        if (loopStartMs >= 0L && loopEndMs > loopStartMs) {
            btnAbLoop.setText("A⇄B");
            DynamicThemeRenderer.applySelectedTileBackground(btnAbLoop, currentPalette, density, 14f);
            btnAbLoop.setTextColor(currentPalette.primaryNeon);
            lastAbLoopState = 2;
        } else if (loopStartMs >= 0L) {
            btnAbLoop.setText("A: " + TimeFormatter.formatDuration(loopStartMs));
            DynamicThemeRenderer.applySelectedTileBackground(btnAbLoop, currentPalette, density, 14f);
            btnAbLoop.setTextColor(currentPalette.secondaryNeon);
            lastAbLoopState = 1;
        } else if (lastAbLoopState != 0) {
            lastAbLoopState = 0;
            btnAbLoop.setText(R.string.badge_ab_loop);
            btnAbLoop.setBackgroundResource(R.drawable.bg_pill_badge);
            btnAbLoop.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        } else {
            btnAbLoop.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        }
    }

    private void updatePlaybackProgress() {
        if (mediaController == null || isUserSeeking) return;
        long duration = mediaController.getDuration();
        long position = Math.max(0L, mediaController.getCurrentPosition());
        if (loopStartMs >= 0L && loopEndMs > loopStartMs && position >= loopEndMs) {
            mediaController.seekTo(loopStartMs);
            position = loopStartMs;
        }
        if (duration > 0) {
            if (duration != lastProgressDurMs) {
                lastProgressDurMs = duration;
                seekBarProgress.setMax((int) duration);
            }
            long totalSec = duration / 1000L;
            if (totalSec != lastProgressTotalSec) {
                lastProgressTotalSec = totalSec;
                textTotalTime.setText(TimeFormatter.formatDuration(duration));
            }
        }
        seekBarProgress.setProgress((int) position);
        long posSec = position / 1000L;
        if (posSec != lastProgressPosSec) {
            lastProgressPosSec = posSec;
            textCurrentTime.setText(TimeFormatter.formatDuration(position));
        }
        if (uiStyleController != null) {
            uiStyleController.updateProgress(position, duration);
        }
    }

    private void syncControllerStateToUi() {
        if (mediaController == null) return;
        boolean playing = mediaController.isPlaying();
        btnPlayPause.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        waveformView.setPlaying(playing);
        if (uiStyleController != null) {
            uiStyleController.updatePlayingState(playing);
        }
        updateShuffleAndRepeatUi();

        MediaItem currentItem = mediaController.getCurrentMediaItem();
        if (currentItem != null) {
            for (Track t : allTracks) {
                if (t.getId().equals(currentItem.mediaId)) {
                    bindHeroTrack(t);
                    break;
                }
            }
        }
        if (activeTrack != null) {
            trackAdapter.setPlaybackState(activeTrack.getId(), playing);
        }
        updatePlaybackProgress();
    }

    private void showOptionsBottomSheet() {
        BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.NeonBottomSheetTheme);
        View sheetView = getLayoutInflater().inflate(R.layout.bottom_sheet_options, null);
        dialog.setContentView(sheetView);

        View btnUiStudioSheet = sheetView.findViewById(R.id.sheet_btn_ui_studio);
        if (btnUiStudioSheet != null) {
            btnUiStudioSheet.setOnClickListener(v -> {
                dialog.dismiss();
                openUiStyleStudio();
            });
        }

        sheetView.findViewById(R.id.sheet_btn_lyrics).setOnClickListener(v -> {
            dialog.dismiss();
            if (activeTrack != null) showLyricsDialog(activeTrack);
        });
        sheetView.findViewById(R.id.sheet_btn_add_playlist).setOnClickListener(v -> {
            dialog.dismiss();
            if (activeTrack != null) showPlaylistPickerDialog(activeTrack);
        });
        sheetView.findViewById(R.id.sheet_btn_share).setOnClickListener(v -> {
            dialog.dismiss();
            if (activeTrack != null) shareAudioTrack(activeTrack);
        });

        sheetView.findViewById(R.id.sheet_btn_jump_back).setOnClickListener(v -> {
            if (mediaController != null && mediaController.getMediaItemCount() > 0) {
                long target = Math.max(0L, mediaController.getCurrentPosition() - 10_000L);
                mediaController.seekTo(target);
                updatePlaybackProgress();
            }
        });
        sheetView.findViewById(R.id.sheet_btn_jump_fwd).setOnClickListener(v -> {
            if (mediaController != null && mediaController.getMediaItemCount() > 0) {
                long dur = mediaController.getDuration();
                long next = mediaController.getCurrentPosition() + 10_000L;
                long target = dur > 0 ? Math.min(dur, next) : next;
                mediaController.seekTo(target);
                updatePlaybackProgress();
            }
        });

        // Pro FX Sliders
        TextView bassLabel = sheetView.findViewById(R.id.label_bass_boost);
        SeekBar seekBass = sheetView.findViewById(R.id.seek_bass_boost);
        seekBass.setProgress(fxEngine.getBassBoostPercent());
        bassLabel.setText(getString(R.string.fx_bass_boost) + ": " + fxEngine.getBassBoostPercent() + "%");
        seekBass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                bassLabel.setText(getString(R.string.fx_bass_boost) + ": " + p + "%");
                if (fromUser) fxEngine.setBassBoostPercent(p);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        TextView virtLabel = sheetView.findViewById(R.id.label_virtualizer);
        SeekBar seekVirt = sheetView.findViewById(R.id.seek_virtualizer);
        seekVirt.setProgress(fxEngine.getVirtualizerPercent());
        virtLabel.setText(getString(R.string.fx_virtualizer) + ": " + fxEngine.getVirtualizerPercent() + "%");
        seekVirt.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                virtLabel.setText(getString(R.string.fx_virtualizer) + ": " + p + "%");
                if (fromUser) fxEngine.setVirtualizerPercent(p);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        TextView loudLabel = sheetView.findViewById(R.id.label_loudness);
        SeekBar seekLoud = sheetView.findViewById(R.id.seek_loudness);
        seekLoud.setProgress(fxEngine.getLoudnessPercent());
        loudLabel.setText(getString(R.string.fx_loudness) + ": " + fxEngine.getLoudnessPercent() + "%");
        seekLoud.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                loudLabel.setText(getString(R.string.fx_loudness) + ": " + p + "%");
                if (fromUser) fxEngine.setLoudnessPercent(p);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        MaterialSwitch switchSkipSilence = sheetView.findViewById(R.id.switch_skip_silence);
        switchSkipSilence.setChecked(fxEngine.isSkipSilenceEnabled());
        switchSkipSilence.setOnCheckedChangeListener((buttonView, isChecked) -> {
            fxEngine.setSkipSilenceEnabled(isChecked);
            if (mediaController != null) {
                mediaController.sendCustomCommand(
                        new SessionCommand(NeonAudioService.CMD_SYNC_AUDIO_PREFS, Bundle.EMPTY),
                        Bundle.EMPTY);
            }
        });

        MaterialSwitch switchSmoothFade = sheetView.findViewById(R.id.switch_smooth_fade);
        switchSmoothFade.setChecked(fxEngine.isSmoothFadeEnabled());
        switchSmoothFade.setOnCheckedChangeListener((buttonView, isChecked) ->
                fxEngine.setSmoothFadeEnabled(isChecked));

        MaterialSwitch switchDynamicTheme = sheetView.findViewById(R.id.switch_dynamic_theme);
        switchDynamicTheme.setChecked(fxEngine.isDynamicThemeEnabled());
        switchDynamicTheme.setOnCheckedChangeListener((buttonView, isChecked) -> {
            fxEngine.setDynamicThemeEnabled(isChecked);
            if (isChecked && activeTrack != null && currentAlbumBitmap != null && !currentAlbumBitmap.isRecycled()) {
                extractAndApplyDynamicTheme(activeTrack.getId(), currentAlbumBitmap);
            } else {
                animateToPalette(NeonPalette.DEFAULT);
            }
        });

        // Speed & Pitch
        ChipGroup speedGroup = sheetView.findViewById(R.id.chip_group_speed);
        if (currentPlaybackSpeed == 0.75f) ((Chip) sheetView.findViewById(R.id.chip_speed_075)).setChecked(true);
        else if (currentPlaybackSpeed == 1.25f) ((Chip) sheetView.findViewById(R.id.chip_speed_125)).setChecked(true);
        else if (currentPlaybackSpeed == 1.5f) ((Chip) sheetView.findViewById(R.id.chip_speed_150)).setChecked(true);
        else ((Chip) sheetView.findViewById(R.id.chip_speed_100)).setChecked(true);

        speedGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_speed_075) currentPlaybackSpeed = 0.75f;
            else if (id == R.id.chip_speed_125) currentPlaybackSpeed = 1.25f;
            else if (id == R.id.chip_speed_150) currentPlaybackSpeed = 1.5f;
            else currentPlaybackSpeed = 1.0f;
            if (mediaController != null) {
                mediaController.setPlaybackParameters(new PlaybackParameters(currentPlaybackSpeed, currentPlaybackPitch));
            }
        });

        ChipGroup pitchGroup = sheetView.findViewById(R.id.chip_group_pitch);
        if (currentPlaybackPitch == 0.85f) ((Chip) sheetView.findViewById(R.id.chip_pitch_085)).setChecked(true);
        else if (currentPlaybackPitch == 1.15f) ((Chip) sheetView.findViewById(R.id.chip_pitch_115)).setChecked(true);
        else ((Chip) sheetView.findViewById(R.id.chip_pitch_100)).setChecked(true);

        pitchGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_pitch_085) currentPlaybackPitch = 0.85f;
            else if (id == R.id.chip_pitch_115) currentPlaybackPitch = 1.15f;
            else currentPlaybackPitch = 1.0f;
            if (mediaController != null) {
                mediaController.setPlaybackParameters(new PlaybackParameters(currentPlaybackSpeed, currentPlaybackPitch));
            }
        });

        ChipGroup sleepGroup = sheetView.findViewById(R.id.chip_group_sleep);
        if (sleepMinutesSelected == 15) ((Chip) sheetView.findViewById(R.id.chip_sleep_15)).setChecked(true);
        else if (sleepMinutesSelected == 30) ((Chip) sheetView.findViewById(R.id.chip_sleep_30)).setChecked(true);
        else if (sleepMinutesSelected == 60) ((Chip) sheetView.findViewById(R.id.chip_sleep_60)).setChecked(true);
        else ((Chip) sheetView.findViewById(R.id.chip_sleep_off)).setChecked(true);

        sleepGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            mainHandler.removeCallbacks(sleepTimerRunnable);
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_sleep_15) sleepMinutesSelected = 15;
            else if (id == R.id.chip_sleep_30) sleepMinutesSelected = 30;
            else if (id == R.id.chip_sleep_60) sleepMinutesSelected = 60;
            else sleepMinutesSelected = 0;

            if (sleepMinutesSelected > 0) {
                mainHandler.postDelayed(sleepTimerRunnable, sleepMinutesSelected * 60_000L);
            }
        });

        // Media & Adaptive Optimization Controls
        TextView optimizerStatusText = sheetView.findViewById(R.id.sheet_optimizer_status_text);
        updateOptimizerTelemetryText(optimizerStatusText);

        ChipGroup optModeGroup = sheetView.findViewById(R.id.chip_group_opt_mode);
        DeviceResourceOptimizer.OptimizationMode activeOptMode = resourceOptimizer.getMode();
        if (activeOptMode == DeviceResourceOptimizer.OptimizationMode.PERFORMANCE) {
            ((Chip) sheetView.findViewById(R.id.chip_opt_performance)).setChecked(true);
        } else if (activeOptMode == DeviceResourceOptimizer.OptimizationMode.ECO_BATTERY) {
            ((Chip) sheetView.findViewById(R.id.chip_opt_eco)).setChecked(true);
        } else {
            ((Chip) sheetView.findViewById(R.id.chip_opt_auto)).setChecked(true);
        }
        optModeGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int id = checkedIds.get(0);
            if (id == R.id.chip_opt_performance) {
                resourceOptimizer.setMode(DeviceResourceOptimizer.OptimizationMode.PERFORMANCE);
            } else if (id == R.id.chip_opt_eco) {
                resourceOptimizer.setMode(DeviceResourceOptimizer.OptimizationMode.ECO_BATTERY);
            } else {
                resourceOptimizer.setMode(DeviceResourceOptimizer.OptimizationMode.AUTO);
            }
            updateOptimizerTelemetryText(optimizerStatusText);
            syncAudioServicePrefs();
        });

        MaterialSwitch switchAntiStutter = sheetView.findViewById(R.id.switch_anti_stutter);
        switchAntiStutter.setChecked(resourceOptimizer.isMediaAntiStutterEnabled());
        switchAntiStutter.setOnCheckedChangeListener((buttonView, isChecked) -> {
            resourceOptimizer.setMediaAntiStutterEnabled(isChecked);
            updateOptimizerTelemetryText(optimizerStatusText);
            syncAudioServicePrefs();
        });

        MaterialSwitch switchAudioOffload = sheetView.findViewById(R.id.switch_audio_offload);
        switchAudioOffload.setChecked(resourceOptimizer.isAudioOffloadPreferred());
        switchAudioOffload.setOnCheckedChangeListener((buttonView, isChecked) -> {
            resourceOptimizer.setAudioOffloadPreferred(isChecked);
            updateOptimizerTelemetryText(optimizerStatusText);
            syncAudioServicePrefs();
        });

        sheetView.findViewById(R.id.sheet_btn_optimize_ram).setOnClickListener(v -> {
            if (themeAnimator != null && themeAnimator.isRunning()) {
                themeAnimator.cancel();
            }
            repository.clearArtCache();
            resourceOptimizer.triggerManualMemoryOptimization();
            updateOptimizerTelemetryText(optimizerStatusText);
            Toast.makeText(this, R.string.opt_cache_cleaned_toast, Toast.LENGTH_SHORT).show();
        });

        TextView trackInfoText = sheetView.findViewById(R.id.sheet_track_info_text);
        if (activeTrack != null) {
            trackInfoText.setText(String.format(Locale.US,
                    "Title: %s\nArtist: %s\nFolder: %s\nFormat: %s  (%s)\nBitrate: %s  •  Sample Rate: %d Hz\nSize: %s",
                    activeTrack.getTitle(),
                    activeTrack.getArtist(),
                    activeTrack.getFolderName(),
                    activeTrack.getFormat(),
                    activeTrack.getMimeType(),
                    activeTrack.getBitrateBadgeText(),
                    activeTrack.getSampleRateHz(),
                    TimeFormatter.formatFileSize(activeTrack.getSizeBytes())
            ));
        } else {
            trackInfoText.setText("No track loaded yet. Pick any MP3, FLAC, WAV, AAC, M4A, OGG, or OPUS file.");
        }

        TextView permissionsText = sheetView.findViewById(R.id.sheet_permissions_text);
        permissionsText.setText(String.format(Locale.US,
                "Audio Library Access: %s\nMedia Notifications: %s\nLive Audio Visualizer FFT: %s",
                PermissionHelper.hasAudioReadPermission(this) ? "Granted" : "Not Granted",
                PermissionHelper.hasNotificationPermission(this) ? "Granted" : "Not Granted",
                PermissionHelper.hasRecordAudioPermission(this) ? "Granted (Hardware FFT)" : "Optional (Smooth Wave Fallback)"
        ));

        MaterialButton btnGrantSheet = sheetView.findViewById(R.id.sheet_btn_request_all_perms);
        String[] missing = PermissionHelper.getAllMissingPermissions(this, true);
        btnGrantSheet.setVisibility(missing.length > 0 ? View.VISIBLE : View.GONE);
        btnGrantSheet.setOnClickListener(v -> {
            dialog.dismiss();
            requestPermissionsWithVisualizer();
        });

        dialog.show();
    }

    private void syncAudioServicePrefs() {
        if (mediaController != null) {
            mediaController.sendCustomCommand(
                    new SessionCommand(NeonAudioService.CMD_SYNC_AUDIO_PREFS, Bundle.EMPTY),
                    Bundle.EMPTY);
        }
    }

    private void applyAdaptiveOptimizationProfile() {
        if (resourceOptimizer == null) return;
        int targetFps = resourceOptimizer.getTargetVisualFps();
        if (waveformView != null) {
            waveformView.setTargetFps(targetFps);
        }
        if (uiStyleController != null) {
            uiStyleController.setTargetVisualFps(targetFps);
        }
        fxEngine.updateAdaptiveVisualizerRate(this);
    }

    private void updateOptimizerTelemetryText(TextView statusView) {
        if (statusView == null || resourceOptimizer == null) return;
        DeviceResourceOptimizer.DeviceTelemetry t = resourceOptimizer.evaluateTelemetry();
        int targetFps = resourceOptimizer.getTargetVisualFps();
        int cacheKb = repository != null ? repository.getArtCacheKb() : 0;
        String flags = (t.isThermalThrottled ? "Thermal Guard • " : "")
                + (t.isPowerSaveMode ? "Battery Saver • " : "")
                + (t.isLowRamDevice || t.isSystemLowMemory ? "Low-RAM Guard • " : "");
        statusView.setText(String.format(Locale.US,
                "Tier: %s  •  FPS Cap: %d Hz (Display %d Hz)\nRAM Free: %d / %d MB  •  Heap: %d%%  •  Art Cache: %d KB\n%sCores: %d  •  Offload: %s",
                t.effectiveTier.name(),
                targetFps,
                t.displayRefreshHz,
                t.availRamMb,
                t.totalRamMb,
                t.appHeapUsedPercent,
                cacheKb,
                flags,
                t.cpuCores,
                resourceOptimizer.shouldUseAudioOffload(fxEngine.isEqEnabled()) ? "Active" : "Standby (EQ)"
        ));
    }

    @Override
    protected void onStart() {
        super.onStart();
        SessionToken sessionToken = new SessionToken(
                this, new ComponentName(this, NeonAudioService.class));
        controllerFuture = new MediaController.Builder(this, sessionToken).buildAsync();
        controllerFuture.addListener(() -> {
            try {
                mediaController = controllerFuture.get();
                mediaController.addListener(playerListener);
                syncControllerStateToUi();
            } catch (Exception ignored) {}
        }, ContextCompat.getMainExecutor(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (PermissionHelper.hasAudioReadPermission(this) && allTracks.isEmpty()) {
            refreshLibrary(false);
        }
        if (uiStyleController != null) {
            uiStyleController.syncRetroKnobsFromSystemAndFx();
        }
        fxEngine.setVisualizerListener(this, (bars, energy) ->
                runOnUiThread(() -> {
                    waveformView.updateSpectrum(bars, energy);
                    if (uiStyleController != null) {
                        uiStyleController.updateSpectrum(bars, energy);
                    }
                }));
        mainHandler.removeCallbacks(progressRunnable);
        mainHandler.post(progressRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mainHandler.removeCallbacks(progressRunnable);
        fxEngine.setVisualizerListener(this, null);
        if (activeTrack != null && mediaController != null) {
            repository.saveLastPlaybackState(activeTrack.getId(), mediaController.getCurrentPosition());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mediaController != null) {
            mediaController.removeListener(playerListener);
            mediaController = null;
        }
        if (controllerFuture != null) {
            MediaController.releaseFuture(controllerFuture);
            controllerFuture = null;
        }
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (repository != null) {
            repository.trimMemory(level);
        }
        if (resourceOptimizer != null && resourceOptimizer.isSevereMemoryTrimLevel(level)) {
            if (themeAnimator != null) {
                themeAnimator.cancel();
            }
            applyAdaptiveOptimizationProfile();
        }
    }

    @Override
    protected void onDestroy() {
        if (resourceOptimizer != null) {
            resourceOptimizer.removeListener(optimizerListener);
        }
        if (themeAnimator != null) {
            themeAnimator.cancel();
            themeAnimator = null;
        }
        if (activeLyricsDialog != null && activeLyricsDialog.isShowing()) {
            activeLyricsDialog.dismiss();
        }
        activeLyricsDialog = null;
        activeLyricsContainer = null;
        activeLyricsScroll = null;
        pendingLrcTargetTrack = null;
        mainHandler.removeCallbacksAndMessages(null);
        paletteExecutor.shutdownNow();
        if (repository != null) {
            repository.shutdown();
        }
        super.onDestroy();
    }

    private final Player.Listener playerListener = new Player.Listener() {
        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            btnPlayPause.setImageResource(isPlaying ? R.drawable.ic_pause : R.drawable.ic_play);
            waveformView.setPlaying(isPlaying);
            if (uiStyleController != null) {
                uiStyleController.updatePlayingState(isPlaying);
            }
            if (activeTrack != null) {
                trackAdapter.setPlaybackState(activeTrack.getId(), isPlaying);
            }
            if (isPlaying) {
                mainHandler.removeCallbacks(progressRunnable);
                mainHandler.post(progressRunnable);
            }
        }

        @Override
        public void onMediaItemTransition(MediaItem mediaItem, int reason) {
            syncControllerStateToUi();
            if (mediaItem != null) {
                repository.recordRecentPlay(mediaItem.mediaId);
            }
        }

        @Override
        public void onPlaybackStateChanged(int playbackState) {
            updatePlaybackProgress();
        }

        @Override
        public void onShuffleModeEnabledChanged(boolean shuffleModeEnabled) {
            updateShuffleAndRepeatUi();
        }

        @Override
        public void onRepeatModeChanged(int repeatMode) {
            updateShuffleAndRepeatUi();
        }

        @Override
        public void onPlayerError(@NonNull PlaybackException error) {
            Toast.makeText(
                    MainActivity.this,
                    "Unable to decode audio: " + error.getErrorCodeName(),
                    Toast.LENGTH_SHORT
            ).show();
        }
    };
}
