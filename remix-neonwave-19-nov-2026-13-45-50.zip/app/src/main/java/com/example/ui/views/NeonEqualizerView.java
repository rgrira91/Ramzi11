package com.example.ui.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.annotation.Nullable;
import com.example.audio.AudioFxEngine;

public class NeonEqualizerView extends View {
    public interface OnBandChangedListener {
        void onBandChanged(int bandIndex, float gainDb);
    }

    private static final int BAND_COUNT = AudioFxEngine.UI_BAND_COUNT;
    private static final String[] BAND_LABELS = {
            "32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K"
    };

    private final float[] gainsDb = new float[BAND_COUNT];
    private final int[] bandColors = new int[BAND_COUNT];
    private final Paint trackBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint activeFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint activeGlowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbHaloPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint thumbCorePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tempRect = new RectF();

    private Shader cachedHorizShader;
    private OnBandChangedListener listener;
    private int activeTouchBand = -1;
    private float density = 1f;
    private boolean eqEnabled = true;

    private int colorLow = 0xFF22D3EE;
    private int colorMid = 0xFFA855F7;
    private int colorHigh = 0xFFF43F9E;

    public NeonEqualizerView(Context context) {
        super(context);
        init(context);
    }

    public NeonEqualizerView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public NeonEqualizerView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        density = context.getResources().getDisplayMetrics().density;

        trackBgPaint.setStyle(Paint.Style.FILL);
        trackBgPaint.setColor(0x33FFFFFF);

        activeFillPaint.setStyle(Paint.Style.FILL);
        activeGlowPaint.setStyle(Paint.Style.FILL);
        thumbHaloPaint.setStyle(Paint.Style.FILL);

        thumbCorePaint.setStyle(Paint.Style.FILL);
        thumbCorePaint.setColor(Color.WHITE);

        labelPaint.setTextAlign(Paint.Align.CENTER);
        labelPaint.setTextSize(10.5f * density);
        labelPaint.setColor(0xFFC4B5FD);

        recomputeBandColors();
    }

    public void setPaletteColors(int secondaryNeon, int tertiaryGlow, int primaryNeon) {
        if (this.colorLow == secondaryNeon
                && this.colorMid == tertiaryGlow
                && this.colorHigh == primaryNeon) {
            return;
        }
        this.colorLow = secondaryNeon;
        this.colorMid = tertiaryGlow;
        this.colorHigh = primaryNeon;
        recomputeBandColors();
        rebuildHorizShader(getWidth());
        if (isShown()) {
            invalidate();
        }
    }

    public void setOnBandChangedListener(OnBandChangedListener listener) {
        this.listener = listener;
    }

    public void setBandsDb(float[] newGains) {
        if (newGains == null) return;
        int len = Math.min(BAND_COUNT, newGains.length);
        System.arraycopy(newGains, 0, gainsDb, 0, len);
        invalidate();
    }

    public void setEqEnabled(boolean enabled) {
        if (this.eqEnabled == enabled) return;
        this.eqEnabled = enabled;
        invalidate();
    }

    private void recomputeBandColors() {
        for (int i = 0; i < BAND_COUNT; i++) {
            float t = (float) i / (BAND_COUNT - 1);
            bandColors[i] = t < 0.5f
                    ? blendColor(colorLow, colorMid, t * 2f)
                    : blendColor(colorMid, colorHigh, (t - 0.5f) * 2f);
        }
    }

    private void rebuildHorizShader(int w) {
        if (w <= 0) {
            cachedHorizShader = null;
            return;
        }
        cachedHorizShader = new LinearGradient(
                0f, 0f, w, 0f,
                new int[]{colorLow, colorMid, colorHigh},
                new float[]{0f, 0.5f, 1f},
                Shader.TileMode.CLAMP
        );
    }

    private static int blendColor(int c1, int c2, float ratio) {
        float inv = 1f - ratio;
        int a = Math.round(Color.alpha(c1) * inv + Color.alpha(c2) * ratio);
        int r = Math.round(Color.red(c1) * inv + Color.red(c2) * ratio);
        int g = Math.round(Color.green(c1) * inv + Color.green(c2) * ratio);
        int b = Math.round(Color.blue(c1) * inv + Color.blue(c2) * ratio);
        return Color.argb(a, r, g, b);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        rebuildHorizShader(w);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float padX = 12f * density;
        float topPad = 12f * density;
        float labelArea = 22f * density;
        float bottomTrackY = h - labelArea - 8f * density;
        float trackHeight = Math.max(40f * density, bottomTrackY - topPad);
        float colWidth = (w - padX * 2f) / BAND_COUNT;
        float trackWidth = 4.5f * density;
        float thumbRadius = 7.5f * density;
        float haloRadius = 13.5f * density;

        activeFillPaint.setShader(eqEnabled ? cachedHorizShader : null);
        if (!eqEnabled) {
            activeFillPaint.setColor(0xFF6B7280);
        }

        for (int i = 0; i < BAND_COUNT; i++) {
            float cx = padX + i * colWidth + colWidth * 0.5f;
            float norm = (gainsDb[i] - AudioFxEngine.MIN_GAIN_DB)
                    / (AudioFxEngine.MAX_GAIN_DB - AudioFxEngine.MIN_GAIN_DB);
            norm = Math.max(0f, Math.min(1f, norm));
            float thumbY = bottomTrackY - norm * trackHeight;

            // 1. Background rail
            tempRect.set(cx - trackWidth * 0.5f, topPad, cx + trackWidth * 0.5f, bottomTrackY);
            canvas.drawRoundRect(tempRect, trackWidth, trackWidth, trackBgPaint);

            // 2. Active neon column below thumb (zero per-frame shader allocation)
            int color = eqEnabled ? bandColors[i] : 0xFF6B7280;
            activeGlowPaint.setColor((color & 0x00FFFFFF) | 0x38000000);
            tempRect.set(cx - trackWidth * 1.15f, thumbY, cx + trackWidth * 1.15f, bottomTrackY);
            canvas.drawRoundRect(tempRect, trackWidth, trackWidth, activeGlowPaint);

            tempRect.set(cx - trackWidth * 0.55f, thumbY, cx + trackWidth * 0.55f, bottomTrackY);
            canvas.drawRoundRect(tempRect, trackWidth, trackWidth, activeFillPaint);

            // 3. Luminous neon thumb + outer halo
            float activeHaloR = (activeTouchBand == i) ? haloRadius * 1.25f : haloRadius;
            thumbHaloPaint.setColor(eqEnabled ? ((color & 0x00FFFFFF) | 0x2E000000) : 0x226B7280);
            canvas.drawCircle(cx, thumbY, activeHaloR * 1.25f, thumbHaloPaint);
            thumbHaloPaint.setColor(eqEnabled ? ((color & 0x00FFFFFF) | 0x5E000000) : 0x446B7280);
            canvas.drawCircle(cx, thumbY, activeHaloR, thumbHaloPaint);
            canvas.drawCircle(cx, thumbY, thumbRadius, thumbCorePaint);

            // 4. Frequency label
            labelPaint.setColor(activeTouchBand == i ? Color.WHITE : 0xFFC4B5FD);
            canvas.drawText(BAND_LABELS[i], cx, h - 5f * density, labelPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return false;

        float padX = 12f * density;
        float topPad = 12f * density;
        float labelArea = 22f * density;
        float bottomTrackY = h - labelArea - 8f * density;
        float trackHeight = Math.max(40f * density, bottomTrackY - topPad);
        float colWidth = (w - padX * 2f) / BAND_COUNT;

        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(true);
            }
            int idx = (int) ((event.getX() - padX) / colWidth);
            activeTouchBand = Math.max(0, Math.min(BAND_COUNT - 1, idx));
            updateBandFromY(activeTouchBand, event.getY(), topPad, trackHeight, bottomTrackY);
            return true;
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (activeTouchBand >= 0) {
                updateBandFromY(activeTouchBand, event.getY(), topPad, trackHeight, bottomTrackY);
            }
            return true;
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            if (getParent() != null) {
                getParent().requestDisallowInterceptTouchEvent(false);
            }
            activeTouchBand = -1;
            invalidate();
            return true;
        }
        return super.onTouchEvent(event);
    }

    private void updateBandFromY(int bandIndex, float y, float topPad, float trackHeight, float bottomTrackY) {
        float clampedY = Math.max(topPad, Math.min(bottomTrackY, y));
        float norm = (bottomTrackY - clampedY) / trackHeight;
        float newGain = AudioFxEngine.MIN_GAIN_DB + norm * (AudioFxEngine.MAX_GAIN_DB - AudioFxEngine.MIN_GAIN_DB);
        gainsDb[bandIndex] = newGain;
        invalidate();
        if (listener != null) {
            listener.onBandChanged(bandIndex, newGain);
        }
    }
}
