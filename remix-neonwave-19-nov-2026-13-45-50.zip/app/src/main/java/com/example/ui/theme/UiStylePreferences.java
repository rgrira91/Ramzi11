package com.example.ui.theme;

import android.content.Context;
import android.content.SharedPreferences;

public class UiStylePreferences {
    private static final String PREFS_NAME = "neon_wave_ui_style_prefs";
    private static final String KEY_ACTIVE_STYLE = "active_ui_style";
    private static final String KEY_FLOATING_COLLAPSED = "floating_mini_collapsed";
    private static final String KEY_SHOW_EQ_CUSTOM = "show_eq_in_custom_styles";

    private final SharedPreferences prefs;

    public UiStylePreferences(Context context) {
        this.prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public UiStyleMode getActiveStyle() {
        return UiStyleMode.fromKey(prefs.getString(KEY_ACTIVE_STYLE, UiStyleMode.NEON_COSMIC.key));
    }

    public void setActiveStyle(UiStyleMode mode) {
        if (mode == null) mode = UiStyleMode.NEON_COSMIC;
        prefs.edit().putString(KEY_ACTIVE_STYLE, mode.key).apply();
    }

    public boolean isFloatingMiniCollapsed() {
        return prefs.getBoolean(KEY_FLOATING_COLLAPSED, false);
    }

    public void setFloatingMiniCollapsed(boolean collapsed) {
        prefs.edit().putBoolean(KEY_FLOATING_COLLAPSED, collapsed).apply();
    }

    public boolean isShowEqInCustomStyles() {
        return prefs.getBoolean(KEY_SHOW_EQ_CUSTOM, true);
    }

    public void setShowEqInCustomStyles(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_EQ_CUSTOM, show).apply();
    }
}
