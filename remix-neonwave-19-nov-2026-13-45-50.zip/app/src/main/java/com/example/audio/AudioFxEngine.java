package com.example.audio;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.audiofx.BassBoost;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.media.audiofx.Virtualizer;
import android.media.audiofx.Visualizer;
import com.example.model.EqPreset;
import com.example.util.DeviceResourceOptimizer;
import com.example.util.PermissionHelper;

public class AudioFxEngine {
    public static final int UI_BAND_COUNT = 10;
    public static final int[] UI_BAND_FREQUENCIES_HZ = {
            32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000
    };
    public static final float MIN_GAIN_DB = -12.0f;
    public static final float MAX_GAIN_DB = 12.0f;

    private static final String PREFS_NAME = "neon_wave_audio_fx";
    private static final String KEY_EQ_ENABLED = "eq_enabled";
    private static final String KEY_PRESET = "eq_preset";
    private static final String KEY_BAND_PREFIX = "eq_band_";
    private static final String KEY_BASS_PERCENT = "bass_percent";
    private static final String KEY_VIRTUALIZER_PERCENT = "virtualizer_percent";
    private static final String KEY_LOUDNESS_PERCENT = "loudness_percent";
    private static final String KEY_SKIP_SILENCE = "skip_silence";
    private static final String KEY_SMOOTH_FADE = "smooth_fade";
    private static final String KEY_DYNAMIC_THEME = "dynamic_theme";

    public interface VisualizerListener {
        void onSpectrumData(float[] normalizedBars, float energy);
    }

    private static AudioFxEngine instance;

    private final float[] uiBandGainsDb = new float[UI_BAND_COUNT];
    private EqPreset currentPreset = EqPreset.ELECTRONIC;
    private boolean eqEnabled = true;
    private int bassBoostPercent = 65;
    private int virtualizerPercent = 35;
    private int loudnessPercent = 0;
    private boolean skipSilenceEnabled = false;
    private boolean smoothFadeEnabled = true;
    private boolean dynamicThemeEnabled = true;
    private int currentSessionId = 0;

    private Equalizer equalizer;
    private BassBoost bassBoost;
    private Virtualizer virtualizer;
    private LoudnessEnhancer loudnessEnhancer;
    private Visualizer visualizer;
    private VisualizerListener visualizerListener;
    private SharedPreferences prefs;
    private final float[][] reusableVisualizerBars = new float[2][42];
    private int reusableBarBufferIdx = 0;
    private int activeCaptureDivisor = -1;

    private AudioFxEngine() {
        System.arraycopy(EqPreset.ELECTRONIC.getGainsDbCopy(), 0, uiBandGainsDb, 0, UI_BAND_COUNT);
    }

    public static synchronized AudioFxEngine getInstance() {
        if (instance == null) {
            instance = new AudioFxEngine();
        }
        return instance;
    }

    public synchronized void init(Context context) {
        if (prefs == null) {
            prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            eqEnabled = prefs.getBoolean(KEY_EQ_ENABLED, true);
            currentPreset = EqPreset.fromKey(prefs.getString(KEY_PRESET, EqPreset.ELECTRONIC.getKey()));
            bassBoostPercent = prefs.getInt(KEY_BASS_PERCENT, currentPreset.getBassBoostStrength() / 10);
            virtualizerPercent = prefs.getInt(KEY_VIRTUALIZER_PERCENT, 35);
            loudnessPercent = prefs.getInt(KEY_LOUDNESS_PERCENT, 0);
            skipSilenceEnabled = prefs.getBoolean(KEY_SKIP_SILENCE, false);
            smoothFadeEnabled = prefs.getBoolean(KEY_SMOOTH_FADE, true);
            dynamicThemeEnabled = prefs.getBoolean(KEY_DYNAMIC_THEME, true);

            if (currentPreset == EqPreset.CUSTOM) {
                for (int i = 0; i < UI_BAND_COUNT; i++) {
                    uiBandGainsDb[i] = prefs.getFloat(KEY_BAND_PREFIX + i, 0f);
                }
            } else {
                System.arraycopy(currentPreset.getGainsDbCopy(), 0, uiBandGainsDb, 0, UI_BAND_COUNT);
            }
        }
    }

    public synchronized void attachToAudioSession(Context context, int audioSessionId) {
        init(context);
        if (audioSessionId <= 0) {
            return;
        }
        if (currentSessionId == audioSessionId && equalizer != null) {
            applyEffectsToHardware();
            ensureVisualizerAttached(context);
            return;
        }

        releaseHardwareFx();
        currentSessionId = audioSessionId;

        try {
            equalizer = new Equalizer(0, audioSessionId);
            equalizer.setEnabled(eqEnabled);
        } catch (Throwable ignored) {
            equalizer = null;
        }

        try {
            bassBoost = new BassBoost(0, audioSessionId);
            bassBoost.setEnabled(eqEnabled);
        } catch (Throwable ignored) {
            bassBoost = null;
        }

        try {
            virtualizer = new Virtualizer(0, audioSessionId);
            virtualizer.setEnabled(eqEnabled && virtualizerPercent > 0);
        } catch (Throwable ignored) {
            virtualizer = null;
        }

        try {
            loudnessEnhancer = new LoudnessEnhancer(audioSessionId);
            loudnessEnhancer.setEnabled(eqEnabled && loudnessPercent > 0);
        } catch (Throwable ignored) {
            loudnessEnhancer = null;
        }

        applyEffectsToHardware();
        ensureVisualizerAttached(context);
    }

    public synchronized void ensureVisualizerAttached(Context context) {
        if (currentSessionId <= 0 || visualizerListener == null || context == null) {
            return;
        }
        if (!PermissionHelper.hasRecordAudioPermission(context)) {
            return;
        }
        int desiredDivisor = DeviceResourceOptimizer.getInstance(context).getVisualizerCaptureRateDivisor();
        if (visualizer != null) {
            if (activeCaptureDivisor != desiredDivisor) {
                releaseVisualizer();
            } else {
                try {
                    if (!visualizer.getEnabled()) {
                        visualizer.setEnabled(true);
                    }
                    return;
                } catch (Throwable ignored) {
                    releaseVisualizer();
                }
            }
        }

        try {
            visualizer = new Visualizer(currentSessionId);
            int[] sizeRange = Visualizer.getCaptureSizeRange();
            int captureSize = Math.min(256, Math.max(sizeRange[0], 128));
            visualizer.setCaptureSize(captureSize);
            int captureRate = Math.max(1000, Visualizer.getMaxCaptureRate() / Math.max(1, desiredDivisor));
            activeCaptureDivisor = desiredDivisor;
            visualizer.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override
                public void onWaveFormDataCapture(Visualizer v, byte[] waveform, int samplingRate) {}

                @Override
                public void onFftDataCapture(Visualizer v, byte[] fft, int samplingRate) {
                    VisualizerListener listener = visualizerListener;
                    if (fft == null || fft.length < 4 || listener == null) {
                        return;
                    }
                    int barCount = 42;
                    reusableBarBufferIdx ^= 1;
                    float[] bars = reusableVisualizerBars[reusableBarBufferIdx];
                    int bins = fft.length / 2;
                    float sumEnergy = 0f;
                    for (int i = 0; i < barCount; i++) {
                        double norm = (double) i / (barCount - 1);
                        int binIdx = 1 + (int) Math.round(Math.pow(norm, 1.55) * Math.max(1, bins - 2));
                        int rfkIdx = binIdx * 2;
                        int ifkIdx = rfkIdx + 1;
                        if (ifkIdx < fft.length) {
                            float re = fft[rfkIdx];
                            float im = fft[ifkIdx];
                            float mag = (float) Math.hypot(re, im);
                            float normalized = Math.min(1f, (float) (Math.log10(1.0 + mag * 1.6) / 2.05));
                            bars[i] = normalized;
                            sumEnergy += normalized;
                        } else {
                            bars[i] = 0f;
                        }
                    }
                    listener.onSpectrumData(bars, sumEnergy / barCount);
                }
            }, captureRate, false, true);
            visualizer.setEnabled(true);
        } catch (Throwable ignored) {
            releaseVisualizer();
        }
    }

    public synchronized void updateAdaptiveVisualizerRate(Context context) {
        if (context == null || visualizerListener == null || currentSessionId <= 0) {
            return;
        }
        int desiredDivisor = DeviceResourceOptimizer.getInstance(context).getVisualizerCaptureRateDivisor();
        if (visualizer != null && activeCaptureDivisor != desiredDivisor) {
            ensureVisualizerAttached(context);
        }
    }

    public synchronized void setVisualizerListener(Context context, VisualizerListener listener) {
        this.visualizerListener = listener;
        if (listener == null) {
            // Stop hardware FFT capture immediately when UI goes to background to save battery/CPU
            setVisualizerActive(false);
        } else if (currentSessionId > 0) {
            ensureVisualizerAttached(context);
        }
    }

    public synchronized void setVisualizerActive(boolean active) {
        if (active && visualizerListener == null) {
            return;
        }
        if (visualizer != null) {
            try {
                if (visualizer.getEnabled() != active) {
                    visualizer.setEnabled(active);
                }
            } catch (Throwable ignored) {}
        }
    }

    public synchronized void setEqEnabled(boolean enabled) {
        this.eqEnabled = enabled;
        saveState();
        applyEffectsToHardware();
    }

    public synchronized boolean isEqEnabled() { return eqEnabled; }
    public synchronized EqPreset getCurrentPreset() { return currentPreset; }
    public synchronized float[] getUiBandGainsDb() { return uiBandGainsDb.clone(); }
    public synchronized int getBassBoostPercent() { return bassBoostPercent; }
    public synchronized int getVirtualizerPercent() { return virtualizerPercent; }
    public synchronized int getLoudnessPercent() { return loudnessPercent; }
    public synchronized boolean isSkipSilenceEnabled() { return skipSilenceEnabled; }
    public synchronized boolean isSmoothFadeEnabled() { return smoothFadeEnabled; }
    public synchronized boolean isDynamicThemeEnabled() { return dynamicThemeEnabled; }

    public synchronized void setSkipSilenceEnabled(boolean enabled) {
        this.skipSilenceEnabled = enabled;
        saveState();
    }

    public synchronized void setSmoothFadeEnabled(boolean enabled) {
        this.smoothFadeEnabled = enabled;
        saveState();
    }

    public synchronized void setDynamicThemeEnabled(boolean enabled) {
        this.dynamicThemeEnabled = enabled;
        saveState();
    }

    public synchronized void setBassBoostPercent(int percent) {
        this.bassBoostPercent = Math.max(0, Math.min(100, percent));
        saveState();
        applyEffectsToHardware();
    }

    public synchronized void setVirtualizerPercent(int percent) {
        this.virtualizerPercent = Math.max(0, Math.min(100, percent));
        saveState();
        applyEffectsToHardware();
    }

    public synchronized void setLoudnessPercent(int percent) {
        this.loudnessPercent = Math.max(0, Math.min(100, percent));
        saveState();
        applyEffectsToHardware();
    }

    public synchronized void applyPreset(EqPreset preset) {
        this.currentPreset = preset;
        if (preset != EqPreset.CUSTOM) {
            System.arraycopy(preset.getGainsDbCopy(), 0, uiBandGainsDb, 0, UI_BAND_COUNT);
            this.bassBoostPercent = preset.getBassBoostStrength() / 10;
        }
        saveState();
        applyEffectsToHardware();
    }

    public synchronized void setUiBandGainDb(int uiBandIndex, float gainDb) {
        if (uiBandIndex < 0 || uiBandIndex >= UI_BAND_COUNT) return;
        float clamped = Math.max(MIN_GAIN_DB, Math.min(MAX_GAIN_DB, gainDb));
        uiBandGainsDb[uiBandIndex] = clamped;
        currentPreset = EqPreset.CUSTOM;
        saveState();
        applyEffectsToHardware();
    }

    private void saveState() {
        if (prefs == null) return;
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(KEY_EQ_ENABLED, eqEnabled);
        editor.putString(KEY_PRESET, currentPreset.getKey());
        editor.putInt(KEY_BASS_PERCENT, bassBoostPercent);
        editor.putInt(KEY_VIRTUALIZER_PERCENT, virtualizerPercent);
        editor.putInt(KEY_LOUDNESS_PERCENT, loudnessPercent);
        editor.putBoolean(KEY_SKIP_SILENCE, skipSilenceEnabled);
        editor.putBoolean(KEY_SMOOTH_FADE, smoothFadeEnabled);
        editor.putBoolean(KEY_DYNAMIC_THEME, dynamicThemeEnabled);
        for (int i = 0; i < UI_BAND_COUNT; i++) {
            editor.putFloat(KEY_BAND_PREFIX + i, uiBandGainsDb[i]);
        }
        editor.apply();
    }

    private void applyEffectsToHardware() {
        if (equalizer != null) {
            try {
                equalizer.setEnabled(eqEnabled);
                short numHwBands = equalizer.getNumberOfBands();
                short[] range = equalizer.getBandLevelRange();
                short minLevel = range[0];
                short maxLevel = range[1];

                for (short hwBand = 0; hwBand < numHwBands; hwBand++) {
                    int centerFreqHz = equalizer.getCenterFreq(hwBand) / 1000;
                    float interpolatedDb = interpolateDbForFrequency(centerFreqHz);
                    float ratio = (interpolatedDb - MIN_GAIN_DB) / (MAX_GAIN_DB - MIN_GAIN_DB);
                    short targetMb = (short) Math.round(minLevel + ratio * (maxLevel - minLevel));
                    targetMb = (short) Math.max(minLevel, Math.min(maxLevel, targetMb));
                    equalizer.setBandLevel(hwBand, targetMb);
                }
            } catch (Throwable ignored) {}
        }

        if (bassBoost != null) {
            try {
                bassBoost.setEnabled(eqEnabled && bassBoostPercent > 0);
                if (bassBoost.getStrengthSupported()) {
                    bassBoost.setStrength((short) (bassBoostPercent * 10));
                }
            } catch (Throwable ignored) {}
        }

        if (virtualizer != null) {
            try {
                virtualizer.setEnabled(eqEnabled && virtualizerPercent > 0);
                if (virtualizer.getStrengthSupported()) {
                    virtualizer.setStrength((short) (virtualizerPercent * 10));
                }
            } catch (Throwable ignored) {}
        }

        if (loudnessEnhancer != null) {
            try {
                loudnessEnhancer.setEnabled(eqEnabled && loudnessPercent > 0);
                // Up to +15 dB (1500 mB) gentle loudness boost
                loudnessEnhancer.setTargetGain(loudnessPercent * 15);
            } catch (Throwable ignored) {}
        }
    }

    private float interpolateDbForFrequency(int freqHz) {
        if (freqHz <= UI_BAND_FREQUENCIES_HZ[0]) return uiBandGainsDb[0];
        if (freqHz >= UI_BAND_FREQUENCIES_HZ[UI_BAND_COUNT - 1]) return uiBandGainsDb[UI_BAND_COUNT - 1];

        for (int i = 0; i < UI_BAND_COUNT - 1; i++) {
            int f1 = UI_BAND_FREQUENCIES_HZ[i];
            int f2 = UI_BAND_FREQUENCIES_HZ[i + 1];
            if (freqHz >= f1 && freqHz <= f2) {
                double logPos = (Math.log(freqHz) - Math.log(f1)) / (Math.log(f2) - Math.log(f1));
                return (float) (uiBandGainsDb[i] + logPos * (uiBandGainsDb[i + 1] - uiBandGainsDb[i]));
            }
        }
        return 0f;
    }

    public synchronized void releaseVisualizer() {
        if (visualizer != null) {
            try {
                visualizer.setEnabled(false);
                visualizer.release();
            } catch (Throwable ignored) {}
            visualizer = null;
        }
        activeCaptureDivisor = -1;
    }

    public synchronized void releaseHardwareFx() {
        releaseVisualizer();
        if (equalizer != null) {
            try { equalizer.release(); } catch (Throwable ignored) {}
            equalizer = null;
        }
        if (bassBoost != null) {
            try { bassBoost.release(); } catch (Throwable ignored) {}
            bassBoost = null;
        }
        if (virtualizer != null) {
            try { virtualizer.release(); } catch (Throwable ignored) {}
            virtualizer = null;
        }
        if (loudnessEnhancer != null) {
            try { loudnessEnhancer.release(); } catch (Throwable ignored) {}
            loudnessEnhancer = null;
        }
        currentSessionId = 0;
    }
}
