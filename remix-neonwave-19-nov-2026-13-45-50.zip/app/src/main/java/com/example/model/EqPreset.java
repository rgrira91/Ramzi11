package com.example.model;

import androidx.annotation.DrawableRes;
import androidx.annotation.StringRes;
import com.example.R;

public enum EqPreset {
    FLAT(
            "flat",
            R.string.preset_flat,
            R.drawable.ic_preset_flat,
            new float[]{0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f},
            0
    ),
    POP(
            "pop",
            R.string.preset_pop,
            R.drawable.ic_preset_pop,
            new float[]{-1.5f, 1.0f, 3.0f, 4.0f, 3.5f, 1.0f, -1.0f, 1.5f, 3.0f, 3.5f},
            250
    ),
    ROCK(
            "rock",
            R.string.preset_rock,
            R.drawable.ic_preset_rock,
            new float[]{4.5f, 3.5f, 2.0f, -1.0f, -2.5f, -1.5f, 2.0f, 4.0f, 5.0f, 5.5f},
            450
    ),
    ELECTRONIC(
            "electronic",
            R.string.preset_electronic,
            R.drawable.ic_preset_electronic,
            new float[]{5.0f, 4.5f, 2.5f, 0.5f, -2.0f, 1.5f, 3.0f, 4.5f, 6.0f, 5.5f},
            650
    ),
    BASS_BOOST(
            "bass_boost",
            R.string.preset_bass_boost,
            R.drawable.ic_preset_bass,
            new float[]{8.5f, 7.5f, 5.5f, 3.0f, 1.0f, 0f, 0f, 0.5f, 1.0f, 1.5f},
            900
    ),
    CUSTOM(
            "custom",
            R.string.badge_ten_band_eq,
            R.drawable.ic_equalizer,
            new float[]{0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f},
            300
    );

    private final String key;
    private final int titleRes;
    private final int iconRes;
    private final float[] gainsDb;
    private final int bassBoostStrength;

    EqPreset(String key, @StringRes int titleRes, @DrawableRes int iconRes, float[] gainsDb, int bassBoostStrength) {
        this.key = key;
        this.titleRes = titleRes;
        this.iconRes = iconRes;
        this.gainsDb = gainsDb;
        this.bassBoostStrength = bassBoostStrength;
    }

    public String getKey() { return key; }
    @StringRes public int getTitleRes() { return titleRes; }
    @DrawableRes public int getIconRes() { return iconRes; }
    public float[] getGainsDbCopy() { return gainsDb.clone(); }
    public int getBassBoostStrength() { return bassBoostStrength; }

    public static EqPreset fromKey(String key) {
        for (EqPreset preset : values()) {
            if (preset.key.equals(key)) {
                return preset;
            }
        }
        return ELECTRONIC;
    }
}
